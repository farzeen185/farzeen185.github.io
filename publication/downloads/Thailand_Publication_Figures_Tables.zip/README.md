# Thailand water storage publication release

Farzeen Khan · MS Water Engineering and Management · Asian Institute of Technology
Advisor: Dr. Natthachet Tangdamrongsub

## Current deliverables

- `report/AIT_Report_Farzeen_Khan.pdf` and `.docx`: 50 pages, 32 figures and 6 tables, AIT-style Times New Roman and chapter headings.
- `manuscript/Manuscript_Farzeen_Khan.pdf` and `.docx`: separate 26-page manuscript prepared for advisor review, 10 selected figures.
- `presentation/Thailand_Water_Storage_Seminar.pdf` and `.pptx`: 26 main slides and 8 supporting slides; Metropolis Beamer and editable PowerPoint.
- `presentation/Thailand_Beamer_Source.zip`: standalone LaTeX source and vector figures.
- `Thailand_Publication_Figures_Tables.zip`: 42 unique figures, full-precision tables, provenance and editorial source.
- `inputs/`: frozen NOAA ONI, historical RONI v5 and DMI with provider URLs and hashes.
- `tables/`: verified storage, climate, residual, forcing, validation and ENSO outputs.

Website: https://pratikkhanal16.github.io/thailand-water-storage-dss/
Code: https://github.com/pratikkhanal16/thailand-water-storage-dss
Reproduce the new extension using `research_v6/README.md` in the repository. The original and CSR hydrological rebuilds remain in `research/` and `research_v5/`. The clean independent rerun matched all six new tables. Older releases are archived locally under `archive/`; original scientific data are retained.

## Scientific interpretation

The primary national storage records decline. Climate-memory reconstruction evaluates a naturalized parent model. GLDAS compares matching soil, canopy and snow compartments. The residual R=O−C=H+E is not measured pumping. Wells provide head evidence without an assumed specific yield; reservoirs check one surface-water component. ENSO diagnostics retain all selected lags and index alternatives; none passes the full conservative basin FDR screen. These limitations remain in the manuscript and presentation.

The manuscript requires author/advisor review before submission. Figure design and added analyses do not guarantee journal acceptance. Funding, author order and declarations must be confirmed by the author.
