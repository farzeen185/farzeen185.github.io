"""Fifty-page report (30 results pages) and a plain-language 32-slide seminar."""
from pathlib import Path
import json,csv,math,shutil,re
from v6_research_text import TITLE,AUTHOR,ABSTRACT,SECTIONS
R=Path(__file__).resolve().parents[1];S=R/'Thailand_Publication_v6';V=R/'Thailand_Publication_v7';P=V/'presentation';B=V/'report'
for d in [P/'figures',B/'figures',V/'qa']:d.mkdir(parents=True,exist_ok=True)
C={x['stem']:x for x in json.loads((V/'figure_catalog.json').read_text(encoding='utf-8'))}
def esc(s):
 return ''.join({'&':r'\&','%':r'\%','$':r'\$','#':r'\#','_':r'\_','−':r'$-$','≈':r'$\approx$','³':r'$^3$','Δ':r'$\Delta$','±':r'$\pm$','°':r'$^\circ$'}.get(c,c) for c in str(s))
def rows(name):
 with (S/'tables'/name).open(encoding='utf-8-sig') as f:return list(csv.DictReader(f))
def f(x,n=2):
 try:v=float(x);return f'{v:.{n}f}' if math.isfinite(v) else '—'
 except:return '—'
inv=json.loads((R/'Thailand_Research_v5/basin_forcing_appendix/table_inventory.json').read_text(encoding='utf-8'))
def basin(k):
 x=next(x for x in inv if x['id']==k);out=[]
 for row in rows(x['file']):
  out.append([row[c] if c=='region' else str(int(float(row[c]))) if (c=='n' or c.endswith('_n') or c.endswith('_years')) and row[c] else f(row[c],3 if 'NSE' in c or c=='r' or c.endswith('_r') or c.endswith('_q') else 2) for c in x['columns']])
 return {'title':x['title'],'headers':x['headers'],'rows':out,'note':x['note'].replace('Basin names are listed in Appendix A.','Basin names appear in the temporal panels.')}
pages=[]
def page(title,paras=None,figure=None,height=5.25,table=None,section='',interpretation=None):pages.append({'title':title,'paragraphs':paras or [],'figure':figure,'height':height,'table':table,'section':section,'interpretation':interpretation})
page(TITLE,section='Title')
page('Abstract',[ABSTRACT])
page('Contents',["1 Introduction — 4\n2 Background — 5\n3 Problem statement — 6\n4 Objectives — 7\n5 Study area — 8\n6 Data collection — 9–10\n7 Methodology — 11–14\n8 Results — 15–44\n9 Conclusion — 45\n10 Discussion — 46–47\n11 Further work — 48–49\nReferences — 50","Results occupy 30 of the 50 report pages, or 60%. Each results page states the comparison, the main finding and its interpretation. All 22 basins are retained in the maps, temporal panels and full-precision numerical tables."])
page('1 Introduction',SECTIONS['Introduction'])
page('2 Background',SECTIONS['Literature and research gap'])
page('3 Problem statement',[
 'Thailand needs information on where water storage is changing and whether the change is mainly consistent with climate variability or water management. Rainfall deficits, reduced recharge, reservoir operations and abstraction can occur together. A declining storage series therefore does not identify its cause without additional evidence.',
 'GRACE observes total water mass over broad areas. It does not separately observe groundwater or human water use. Groundwater storage must be derived by removing the other storage compartments. Small-basin results also share gravity information, while the supporting model and monitoring records have different spatial and temporal coverage.',
 'The central problem is that a large observation-minus-climate residual can be mistaken for measured human depletion. This study tests that interpretation rather than assuming it. A convincing assessment must distinguish model reconstruction skill, agreement with matching GLDAS components, and independent checks using groundwater levels and reservoirs.',
 'The practical need is a clear basin assessment that shows both the storage signal and the strength of its supporting evidence. The report therefore gives equal attention to coverage, product sensitivity and failed checks, and presents these limitations alongside usable maps and time series.'
])
page('4 Objectives',[
 'Objective 1: quantify terrestrial and groundwater storage anomalies for every principal basin in Thailand. Describe monthly variability, estimate seasonal Sen slopes, apply Mann–Kendall tests and show the results spatially and through time.',
 'Objective 2: reconstruct a naturalized climate baseline from meteorological information and climate memory. Evaluate the reconstruction chronologically, compare matching land compartments with GLDAS, calculate the residual, and examine what groundwater levels, reservoirs and ENSO diagnostics can support about its interpretation.',
 'Objective 3: provide a clear interactive basin decision-support website with downloadable figures, tables and code that a professor or another researcher can run.',
 'The research questions are whether national decline is consistent across processing chains, whether weather memory improves reconstruction, and whether independent observations support the residual. The study does not assume that a high model score validates human-caused storage loss.'
])
page('5 Study area',[SECTIONS['Study area and reporting scale'][0],SECTIONS['Study area and reporting scale'][2]],'study_area',4.25)
datasets={'title':'Inputs and their scientific roles','headers':['Data','Used for','Key limitation'],'rows':[['CSR GRACE / GRACE-FO','Observed total storage','Broad gravity support'],['GLDAS Noah','Soil canopy and snow','Partial land storage only'],['G3P surface water','Groundwater subtraction','Component uncertainty'],['WaterGAP paired runs','Naturalized / historical storage','Model-defined counterfactual'],['Native P and potential ET','Climate-model predictors','Forcing dependence'],['CHIRPS rainfall','Alternative-forcing test','Different rainfall estimation'],['GLEAM MODIS ESA CCI','Hydroclimatic context','Unequal product coverage'],['GROW groundwater levels','Groundwater-state evidence','Local and mostly annual'],['MSEA-Res Level 1','Reservoir component evidence','Sparse scene observations'],['ONI RONI v5 and DMI','ENSO / IOD diagnostics','Short common record']],'note':'All products retain their original physical definition; a flux, a storage anomaly and a groundwater level are not interchangeable.'}
page('6 Data collection',[SECTIONS['Data and provenance'][2]],table=datasets)
page('6 Data collection and preparation',[
 'The input collection includes downloaded source products, provider documentation, frozen climate indices and file checksums. The original and extended GitHub packages retain the input subsets needed for a complete numerical rerun. The new ENSO extension can also be run from verified derived hydrological inputs without credentials or additional downloads.',
 'Storage is converted to millimetres of equivalent water depth. CSR centimetres are multiplied by ten. Soil, surface, canopy and snow water are referenced consistently to the available 2004–2009 mean. Native rainfall and potential ET rates in mm/day are converted to monthly totals using the actual length of each month when reporting flux summaries.',
 'Basin averages use represented cell area and valid data coverage. Groundwater subtraction requires the relevant components on common valid support. Cross-product comparisons use paired dates. Missing GRACE months, missing well years and absent reservoir scenes are retained as missing; they are not replaced with zero or smoothed into observations.',
 'The primary total-storage record extends from April 2002 to September 2024. Groundwater ends in September 2023 because of component availability. The common ENSO analysis uses 2003–2023. Climate-model testing uses 2016–2023. These differing periods are stated at the relevant result rather than hidden in one common label.'
])
page('7 Methodology storage and trend estimation',[
 'Step 1 harmonizes monthly observations, model outputs, units, reference periods and valid spatial support. Step 2 calculates groundwater storage anomalies using GWSA = TWSA − SMSA − SWSA − CWSA − SWEA. In words, groundwater equals total storage minus soil, surface, canopy and snow storage.',
 'Step 3 estimates a seasonal Sen slope for each basin. It compares the same calendar month across years, reducing distortion by the annual cycle. A slope of −5 mm/year means the anomaly decreases by about 5 mm of equivalent water depth per year over that record. It does not measure the water remaining in an aquifer.',
 'The seasonal Mann–Kendall test evaluates ordered change. Basin probabilities are adjusted for multiple comparisons using false discovery rate. Original probabilities, sample sizes and conditional slope intervals are retained. Serial dependence is examined through annual and resampling sensitivities; a small probability is not proof of a human cause.',
 'National results and processing-chain comparisons provide scale context. All basins remain reporting units below the provider’s approximate small-area caution. Resampling intervals are conditional on the chosen products and dates, so product disagreement is reported separately.'
])
page('7 Methodology climate reconstruction',[
 'The climate baseline is naturalized WaterGAP storage, which excludes the direct human activities represented in its paired historical run. The statistical climate model is an emulator: it reconstructs that baseline from precipitation, potential evapotranspiration, season and weather memory. It is not a global climate projection model.',
 'Ridge, ElasticNet, a spline model and random forest are evaluated and combined using validation performance. Past rainfall and PET help represent delayed storage responses. GRACE storage and groundwater level are excluded from the predictors, preventing those observations from directly teaching the emulator the desired residual.',
 'The chronology is fixed: 1981–1990 warm-up, 1991–2009 training, 2010–2015 validation and 2016–2023 testing. Transformations and tuning use earlier data only. The test period does not choose model weights or ENSO-specific fits. A controlled Ridge comparison tests memory, while a frozen CHIRPS replacement tests forcing sensitivity.',
 'RMSE expresses reconstruction error in mm. Correlation describes timing. NSE compares squared error with a target-mean benchmark: 1 is perfect, 0 equals the mean benchmark and negative is worse. Anomaly NSE removes the training monthly climatology so that seasonal agreement alone cannot dominate the interpretation.'
])
page('7 Methodology residual and GLDAS comparison',[
 'Step 4 calculates the residual as observed storage minus the naturalized climate baseline. The word residual means the part left after subtraction; it does not identify why the difference exists.',
 'The paired historical model provides a separate modeled human effect: historical minus naturalized storage. The remaining unexplained gap is observed minus historical storage. Therefore residual = modeled human effect + unexplained gap, or R = H + E. This exact identity is checked on matched months.',
 'The unexplained gap can include forcing error, model structure, gravity error, component subtraction and unrepresented management. A large negative residual can be consistent with human depletion, but it is not an independently observed pumping record. Additive component trends use calendar-month fixed-effect OLS, because seasonal Sen slopes are not algebraically additive.',
 'Step 5 benchmarks GLDAS only against matching soil, canopy and snow storage. Groundwater and open surface water are excluded. This tests land-component consistency, not full total storage or human effects. GLDAS also enters groundwater subtraction, so groundwater-related comparisons are partly dependent.'
])
page('7 Methodology validation ENSO and uncertainty',[
 'Step 6 compares annual residuals with groundwater levels. Depth to water is negated to give a head-oriented sign, and co-located wells are grouped before averaging. Raw, detrended and balanced-panel comparisons expose changing monitoring support. Head is not converted to storage without representative aquifer properties, so no cross-unit storage RMSE is reported.',
 'Independent reservoir scenes check one surface-water component of the total-storage residual. The primary comparison uses a fixed pre-2004 reservoir population, requires scene support, removes season and trend, and resamples calendar years for a conditional correlation interval. Reservoirs respond to climate and operations together.',
 'ENSO diagnostics use ONI and historical RONI v5, with DMI representing IOD. Selected leads are 0, 3, 6, 9 and 12 months. Partial correlations remove calendar month, linear trend and contemporaneous DMI. Twenty whole-year circular rotations of the 21-year calendar give a minimum diagnostic probability of 1/21; all candidate tests enter the FDR family.',
 'ENSO phases require five consecutive overlapping seasons at ±0.5°C. Phase summaries are descriptive, and held-out model scores are calculated without refitting. No non-significant result proves complete climate removal. The uncertainty assessment keeps product choice, reconstruction error, discrepancy and monitoring coverage visible as separate limitations.'
])

# Exactly thirty result pages, with an explicit interpretation on every page.
result_specs=[
('8 Results national storage change','national_storage','National total and derived groundwater storage decline over their respective primary records. Seasonal Sen rates are −7.51 and −6.84 mm/year. The curves still rise during wet periods: a long-term decline does not imply a steady decrease every month.',None),
('8 Results spatial storage trends','storage_trends','The mapped rates differ among basins, but neighbouring polygons share gravity information. Strong southern rates warrant investigation alongside product sensitivity. Treat the map as regional screening rather than a precise ranking of independent aquifers.',None),
('8 Results trend values for all basins',None,'Read slope magnitude, adjusted probability and the number of observed months together. A small q value is evidence of ordered change within this test; it does not identify pumping or remove all serial-dependence uncertainty.',1),
('8 Results observed histories basins 01 to 11','observed_1','The first eleven basin histories retain seasonality, interannual events and missing satellite months. Groundwater and total storage differ because the groundwater balance removes other compartments. Compare timing and persistence rather than assuming the two amplitudes represent the same quantity.',None),
('8 Results observed histories basins 12 to 22','observed_2','The remaining basin histories show why a single national curve is insufficient. Different trajectories can coexist with national decline. Both the trend window and the component data endpoint influence a basin’s displayed rate.',None),
('8 Results forcing patterns and processing sensitivity','forcing_maps','Rainfall and atmospheric demand vary spatially and supply physical context for storage. These are monthly fluxes, not stored water. Native and CHIRPS rainfall differ in estimation and forcing compatibility; neither is declared more accurate from parent-model skill alone.',None),
('8 Results seasonal rainfall and storage','seasonality','Storage generally reflects accumulated hydrological inputs rather than rainfall in one month. The separate axes show rainfall distribution and mean storage timing. These six examples span geography; all 22 basin records remain in the tables and interactive site.',None),
('8 Results national climate reconstruction','climate_national','The weather model follows the naturalized parent closely in the shaded test years. National held-out NSE is 0.981 for total storage and 0.961 for groundwater. This is strong reconstruction of the parent, not independent validation of the natural counterfactual.',None),
('8 Results total storage reconstruction basins 01 to 11','climate_TWSA_1','The shaded test period was excluded from fitting and model selection. Close curves indicate the emulator reproduces modeled naturalized total storage. Earlier training and validation context must not be counted as independent test evidence.',None),
('8 Results total storage reconstruction basins 12 to 22','climate_TWSA_2','All basins are retained, including differences in amplitude and timing. The model target uses naturalized storage; the agreement shown here does not establish the cause of any GRACE-model mismatch.',None),
('8 Results groundwater reconstruction basins 01 to 11','climate_GWSA_1','Groundwater response is modeled through meteorological memory and parent hydrology. Good agreement shows that weather history reconstructs the parent signal. It does not validate pumping, specific yield or measured aquifer storage.',None),
('8 Results groundwater reconstruction basins 12 to 22','climate_GWSA_2','The second half of the groundwater reconstruction retains the same frozen test design. Basin-level metrics and annual failures are needed alongside these visually close curves to judge performance fairly.',None),
('8 Results held out model agreement','scatter_six','Points near the grey identity line indicate small reconstruction errors. Correlation, RMSE and NSE evaluate the predictions directly. The pink descriptive fit cannot improve those reported scores. Geographical examples are shown here; the next tables retain every basin.',None),
('8 Results total storage model scores',None,'Anomaly NSE asks whether the model reproduces departures from the usual seasonal cycle. It is more demanding than raw seasonal agreement. All scores use the same held-out 2016–2023 parent-model target, making within-table basin comparisons meaningful.',2),
('8 Results groundwater model scores',None,'Groundwater errors are smaller in mm partly because the target has a different variance and component definition. Do not rank groundwater and total-storage models solely by their raw RMSE. Inspect anomaly skill within the same storage target.',3),
('8 Results model performance in space','climate_skill_maps','Anomaly skill differs among basins despite high pooled scores. The map identifies where parent-model reconstruction is less reliable. It remains a model evaluation map, not a map of confidence in human attribution.',None),
('8 Results annual skill and climate memory','annual_skill','The 2022 groundwater anomaly NSE is −1.067: in that year, the reconstruction is worse than its mean benchmark. The failure is retained. Separately, the controlled memory experiment improves national anomaly NSE from 0.283 to 0.890 for total storage and 0.039 to 0.723 for groundwater.',None),
('8 Results GLDAS temporal comparison','gldas_national','National matched land storage has r = 0.969, NSE = 0.738 and RMSE = 52.49 mm across 261 paired months. Similar timing supports land-component consistency. The amplitude differences matter, and this comparison excludes groundwater and surface water.',None),
('8 Results GLDAS basin scores','gldas_maps','Higher NSE and lower RMSE indicate closer agreement for matching land compartments. They cannot validate total storage or human water use. Shared climate drivers and GLDAS involvement in groundwater subtraction limit independence.',None),
('8 Results residual and represented human effect','residual_national','The residual is much larger than the direct human effect represented by the paired model. Much of their difference remains an unexplained observation-model gap. The data therefore do not support labelling the entire residual as measured human depletion.',None),
('8 Results residual trend patterns','residual_maps','Negative residual trends indicate observed storage falling relative to the naturalized baseline. They can combine human influence with observation and model discrepancy. OLS is used here so the additive accounting remains valid on the same months.',None),
('8 Results residual histories basins 01 to 11','residual_1','These histories show the total and groundwater residual on the same basin calendar. Persistence and events can be compared, but a negative value does not identify a unique cause. Missing observations remain gaps rather than inferred depletion.',None),
('8 Results residual histories basins 12 to 22','residual_2','The remaining basins show that residual timing and magnitude vary across Thailand. Interpreting a basin requires the independent evidence and support shown later, not only the colour or sign of its trend.',None),
('8 Results climate and residual variability','variability','Climate and residual contributions to variability change through time. The ratios are based on mean absolute deviation and need not add to one. They must not be converted into complementary climate-versus-human percentages.',None),
('8 Results ENSO timing and storage','enso_lags','At a six-month ONI lead, the national climate-baseline association is about −0.53 for both storage variables, whereas residual correlations are about −0.14. This suggests a clearer descriptive ENSO signal in the baseline. No basin result passes the full conservative FDR screen; low power prevents concluding that climate leakage is absent.',None),
('8 Results reconstruction during ENSO phases','enso_skill','Phase-conditioned reconstruction errors use a frozen model and 96 test months. Months share ENSO episodes and their target variances differ. The chart describes reconstruction under different climate conditions, not an independent forecast of El Niño impacts.',None),
('8 Results groundwater agreement in space','head_maps','National longest-overlap residual–head correlations are only 0.127 for total storage and 0.037 for groundwater. Basin evidence is uneven, and hatched areas lack adequate support. Local groundwater level is useful state evidence but cannot validate the whole human residual.',None),
('8 Results groundwater timing and network effects','head_histories','Agreement changes with station selection and available years. In a strict balanced panel, national groundwater-residual correlation is approximately zero over eight usable years. The illustrated standardized curves compare timing; they do not convert metres of head into millimetres of storage.',None),
('8 Results independent reservoir evidence','reservoir','After season and trend removal, national reservoir storage correlates with the total residual at r = 0.439 over 73 scene-supported months, with year-cluster interval 0.188–0.665. This supports a surface-water component. Reservoir inflow and operating choices are mixed, so it is not human-only or groundwater validation.',None),
('8 Results independent evidence for every basin',None,'The table exposes observation gaps as well as correlations. A basin with missing evidence is not assigned zero impact. Read head agreement together with paired years and reservoir support; neither measurement directly observes a human-only counterfactual.',7)
]
for title,fig,meaning,k in result_specs:page(title,figure=fig,height=6.25 if fig and (fig.startswith(('observed_','climate_TWSA_','climate_GWSA_','residual_')) and fig not in ['residual_maps','residual_national']) else 4.8,table=basin(k) if k else None,section='Results',interpretation=meaning)
assert len(pages)==44
page('9 Conclusion',SECTIONS['Conclusions'])
page('10 Discussion interpreting the evidence',SECTIONS['Discussion'][:2]+['The processing-chain comparison is especially relevant to basin ranking: common-date Spearman correlations are only 0.138 for total storage and 0.027 for groundwater. A stable national negative direction can therefore coexist with an unstable local ordering. The maps should guide where to investigate, not justify a precise local abstraction limit.'])
page('10 Discussion groundwater and human influence',SECTIONS['Discussion'][2:]+['The practical distinction is between detecting a storage change and identifying its cause. Wells add local groundwater-state evidence; reservoirs add surface-water evidence. Together they strengthen interpretation of components, but do not close the national human water balance. Their limitations remain part of the result rather than a footnote to be ignored.'])
page('11 Further work improve observations',[
 'The first priority is a longer, consistent groundwater monitoring panel. Basin agencies should provide historical monthly levels with coordinates, aquifer and screen information, datum, observation dates and quality flags. Keeping the same station population through time is essential for distinguishing physical change from changes in the monitored network.',
 'A defensible conversion from groundwater level to storage additionally needs representative specific yield or storage coefficient, aquifer extent, confinement and vertical connectivity. These properties should be measured or justified by aquifer, rather than assigning one generic value to every basin. Pumping, return flow and recharge information are needed to relate storage change to abstraction.',
 'Reservoir evidence should be expanded using consistent scene-based volumes and documented operating records. River discharge, floodplain water and inundation extent can constrain additional surface-water terms. These observations should be kept independent of any products used to derive the quantity being evaluated.',
 'These additions would improve the ability to distinguish groundwater depletion, surface-water management and climate-driven changes. The immediate output should be a monitoring-gap inventory and a documented common observation panel, rather than another unsupported percentage of human impact.'
])
page('11 Further work strengthen attribution and use',[
 'A methodological priority is to match the effective spatial response of gravity and the subtracted compartments through a justified filtering or forward-model experiment. The effects of basin size and coastal leakage should be assessed before treating fine basin contrasts as independent local signals.',
 'Alternative naturalized hydrological models would test whether the residual depends on the chosen counterfactual. Longer climate records and carefully selected ENSO/IOD alternatives could improve power, but test data must remain separate from model selection. Nonlinear and lagged climate responses should be evaluated with a fixed analysis plan and dependence-aware uncertainty.',
 'The decision-support system should add new observations with versioned provenance, retain missing-data flags and display uncertainty with each basin result. An independent researcher should rerun the numerical pipeline and review the interpretations before the information is used for a management decision.',
 'For publication, the next step is advisor review of the contribution, matched spatial support, source terms, final authorship and declarations. The useful contribution is a transparent basin assessment that distinguishes what is detected, what is modeled and what remains unresolved. Improving presentation helps communication; additional evidence is needed to strengthen causal attribution.'
])
refsetup=(R/'scripts/59_write_publication_documents.py').read_text(encoding='utf-8').split('w=Writer(TITLE)')[0];ns={'__file__':str(R/'scripts/59_write_publication_documents.py')};exec(compile(refsetup,'reference_setup','exec'),ns)
page('References',ns['refs']);assert len(pages)==50

def tabletex(t):
 n=len(t['headers']);cols=''.join(r'>{\raggedright\arraybackslash}p{'+str(round(.925/n,3))+r'\textwidth}' for _ in range(n));out=[r'{\fontsize{9.3}{11}\selectfont\setlength{\tabcolsep}{2pt}\renewcommand{\arraystretch}{1.18}\begin{tabular}{'+cols+r'}\toprule',' & '.join(r'\textbf{'+esc(s)+'}' for s in t['headers'])+r'\\\midrule']
 out += [' & '.join(esc(s) for s in row)+r'\\' for row in t['rows']];out += [r'\bottomrule\end{tabular}}',r'\par\vspace{3mm}{\fontsize{10}{12}\selectfont '+esc(t['note'])+'}\par'];return '\n'.join(out)
tex=[r'''\documentclass[12pt,a4paper]{article}
\usepackage{fontspec,graphicx,geometry,setspace,booktabs,array,xcolor,fancyhdr,hyperref}
\geometry{left=25.4mm,right=25.4mm,top=23mm,bottom=23mm}
\setmainfont{Times New Roman}
\hypersetup{hidelinks}
\urlstyle{same}\emergencystretch=3em
\setlength{\parindent}{0pt}\setlength{\parskip}{7pt}
\pagestyle{fancy}\fancyhf{}\fancyfoot[C]{\thepage}\renewcommand{\headrulewidth}{0pt}
\setstretch{1.5}
\begin{document}''']
for i,x in enumerate(pages):
 if i:tex.append(r'\newpage')
 if i==0:
  tex += [r'\thispagestyle{empty}\vspace*{10mm}\begin{center}{\fontsize{16}{21}\selectfont\bfseries '+esc(TITLE.upper())+r'}\par\vspace{18mm}by\par\vspace{4mm}{\bfseries Farzeen Khan}\par\vspace{15mm}Master of Science in Water Engineering and Management\par Asian Institute of Technology\par\vspace{15mm}Advisor: Dr. Natthachet Tangdamrongsub\par\vspace{15mm}Research report\par October 2026\end{center}'];continue
 tex.append(r'{\fontsize{14}{17}\selectfont\bfseries '+esc(x['title'])+r'}\par\vspace{3mm}')
 if x['figure']:
  stem=x['figure'];shutil.copy2(V/'figures'/(stem+'.pdf'),B/'figures'/(stem+'.pdf'));tex += [r'\begin{center}\includegraphics[width=\textwidth,height='+str(x['height'])+r'in,keepaspectratio]{figures/'+stem+r'.pdf}\end{center}',r'{\fontsize{10.5}{12.5}\selectfont\textbf{'+esc(C[stem]['title'])+'}. '+esc(C[stem]['caption'])+r'}\par\vspace{2mm}']
 if x['table']:tex += [tabletex(x['table'])]
 for para in x['paragraphs']:
  value=esc(para).replace('\n',r'\par ')
  if i==49:
   match=re.search(r'https://\S+',para)
   if match:value=esc(para[:match.start()])+r'\url{'+match.group()+'}'
  tex.append((r'{\setstretch{1.0}\fontsize{9.3}{11}\selectfont\sloppy '+value+r'\par}') if i==49 else value+r'\par')
 if x['interpretation']:tex.append(r'\textbf{Interpretation.} '+esc(x['interpretation'])+r'\par')
tex.append(r'\end{document}');(B/'AIT_Report_Farzeen_Khan.tex').write_text('\n'.join(tex),encoding='utf-8');(V/'report_page_plan.json').write_text(json.dumps(pages,ensure_ascii=False,indent=2),encoding='utf-8')

# The presentation follows the same narrative, with 19 result slides out of 32.
slides=[]
def slide(title,body=None,fig=None,meaning=None,section='',table=None,note=''):
 slides.append({'title':title,'body':body or [],'figure':fig,'interpretation':meaning or [],'section':section,'table':table,'note':note})
slide('Water storage change across Thailand',['A basin assessment of climate variability and the remaining residual','Farzeen Khan','Water Engineering and Management · Asian Institute of Technology','Advisor: Dr. Natthachet Tangdamrongsub'],section='Introduction')
slide('Why water storage matters',['Rainfall tells us how much water arrives. Storage tells us how much remains.','Total water storage includes soil, rivers, reservoirs and groundwater.','This study examines monthly changes across all 22 principal basins.'],section='Introduction')
slide('The problem is identifying the cause',['Storage can fall during drought, increased water use, or both.','GRACE observes total water mass; it does not observe pumping separately.','A model residual needs additional evidence before it can be called a human effect.'],section='Background and problem')
slide('Three research objectives',table=[['Objective','Output'],['1 Storage change','Basin trends and monthly TWSA / GWSA'],['2 Climate and residual','Evaluated reconstruction and component checks'],['3 Decision support','Interactive basin website and runnable code']],section='Objectives')
slide('Thailand’s 22 principal basins',fig='study_area',meaning=['Every basin is included in the maps and tables.','The polygons report basin averages; they do not create independent GRACE resolution.'],section='Study area')
slide('What each dataset contributes',table=[['Data','Question it addresses'],['GRACE and storage components','How is total / groundwater storage changing?'],['Naturalized model and weather','Can climate-related storage be reconstructed?'],['GLDAS matching land storage','Do soil, canopy and snow estimates agree?'],['Wells and reservoir scenes','What independent component evidence exists?']],section='Data collection')
slide('Method 1 calculate storage and trends',['Groundwater = total − soil − surface − canopy − snow storage.','Use common units, the 2004–2009 reference and valid spatial support.','Seasonal Sen slopes describe the rate of change; Mann–Kendall tests assess ordered change.'],section='Methodology',note='A negative anomaly is storage below the reference, not a negative absolute water volume.')
slide('Method 2 test the climate reconstruction',table=[['Stage','Period','Purpose'],['Warm-up','1981–1990','Initialize weather memory'],['Training','1991–2009','Fit weather-storage relationships'],['Validation','2010–2015','Select models and weights'],['Testing','2016–2023','Evaluate unseen years']],section='Methodology',note='NSE: 1 perfect; 0 mean benchmark; negative worse. Anomaly NSE removes the training seasonal cycle.')
slide('Method 3 interpret the residual',['Residual = observed storage − naturalized climate baseline.','It contains the model’s human effect plus an unexplained observation-model gap.','Check matching GLDAS compartments, groundwater levels and reservoirs separately.'],section='Methodology',note='The weather emulator reconstructs the naturalized parent. It does not independently observe the true climate-only counterfactual.')
resultslides=[
('National storage declines','national_storage',['Total storage: −7.51 mm/year.','Derived groundwater: −6.84 mm/year.','Wet-year recovery can occur within a longer decline.']),
('Trend magnitude varies across basins','storage_trends',['Negative colours indicate declining storage.','Use the map for regional screening; neighbouring basins share gravity support.']),
('Basin rankings depend on the processing chain','product_ranks',['National decline persists in both chains.','Basin rank agreement is weak: 0.138 for total and 0.027 for groundwater.']),
('Rainfall and atmospheric demand vary in space','forcing_maps',['Rainfall and potential ET are the model inputs.','These are monthly fluxes; they are not stored water.']),
('Storage responds to the seasonal water balance','seasonality',['Blue boxes show rainfall by month. Pink shows mean storage on the right axis.','Storage integrates preceding rainfall and losses. Six geographical examples are shown.']),
('Weather reconstructs the naturalized parent','climate_national',['Shaded years are unseen test data.','High agreement evaluates the parent model; it does not prove climate-only observational accuracy.']),
('Held-out predictions are close to their target','scatter_six',['The grey line is perfect agreement.','RMSE is error in mm; NSE compares error with a mean benchmark. All 22 basin scores are reported.']),
('Anomaly skill is not spatially uniform','climate_skill_maps',['Higher NSE means better reconstruction.','Anomaly skill removes the usual seasonal cycle, giving a stricter test.']),
('Climate memory improves reconstruction','memory',['Past weather adds information beyond current rainfall and PET.','National anomaly NSE rises from 0.283 to 0.890 for total storage.']),
('A pooled score can hide a weak year','annual_skill',['Groundwater anomaly NSE is −1.067 in 2022.','The model performs worse than the mean benchmark in that year; the failure is retained.']),
('GLDAS checks matching land storage','gldas_national',['National r = 0.969; RMSE = 52.49 mm.','The comparison covers soil, canopy and snow only. It does not validate groundwater or human effects.']),
('GLDAS agreement differs among basins','gldas_maps',['Higher NSE and lower RMSE mean closer agreement for the same land-storage target.','Shared climate and component dependence limit independence.']),
('The residual is larger than the modeled human effect','residual_national',['The residual closely follows the unexplained gap.','The entire residual cannot be treated as measured human depletion.']),
('Residual trends identify where to investigate','residual_maps',['Negative rates mean observations decline relative to the naturalized baseline.','Human influence and model or measurement errors can both contribute.']),
('Variability changes through time','variability',['Climate and residual variability differ from year to year.','These ratios need not add to one. They are not human-versus-climate percentages.']),
('ENSO is clearer in the climate baseline','enso_lags',['At six months, baseline r is about −0.53; residual r is about −0.14.','No basin test passes the conservative FDR screen. This does not prove no remaining climate effect.']),
('ENSO phase scores remain conditional','enso_skill',['The model is frozen across all ENSO phases.','Months share episodes, so these are reconstruction comparisons rather than independent event forecasts.']),
('Groundwater support is weak and uneven','head_maps',['National groundwater-residual / head r is only 0.037.','Head is a local water level, not regional water volume. The balanced-panel result is near zero.']),
('Reservoirs support a surface-water component','reservoir',['Adjusted r = 0.439 across 73 scene-supported months.','Reservoirs respond to climate and operations together; this cannot validate the total human residual.'])]
for title,fig,meaning in resultslides:slide(title,fig=fig,meaning=meaning,section='Results',note=C[fig]['caption'])
slide('Conclusion what the study establishes',['The primary national records show declining total and groundwater storage.','Weather memory reconstructs the naturalized model well, with identifiable weak years.','The residual remains human influence plus unresolved discrepancy; independent evidence is limited.'],section='Conclusion')
slide('Discussion how to use these results',['Storage detection is stronger than precise human attribution.','Product choice and monitoring coverage change local interpretation.','Use basin results to prioritize investigation and monitoring, supported by the downloadable evidence.'],section='Discussion')
slide('Further work that would strengthen the study',['Obtain consistent monthly wells, aquifer properties and pumping records.','Improve surface-water observations and matched GRACE spatial response.','Test alternative naturalized models and longer climate-event records.'],section='Further work')
slide('References and reproducible research',['Ji et al. (2025), climate reconstruction: doi:10.1080/17538947.2025.2557516','Müller Schmied et al. (2024), WaterGAP: doi:10.5194/gmd-17-8817-2024','Chueasa et al. (2024), Thai rainfall and ENSO: doi:10.1016/j.mex.2024.102954','Sharifi et al. (2025), spatial response: doi:10.5194/hess-29-6985-2025','Mahto et al. (2025), reservoirs: doi:10.5194/essd-17-2693-2025'],section='References',note='Code and full bibliography: github.com/pratikkhanal16/thailand-water-storage-dss. Metropolis theme: matze/mtheme.')
assert len(slides)==32
deck=[r'''\documentclass[aspectratio=169,11pt]{beamer}
\usepackage{fontspec,graphicx,booktabs,array}
\usetheme[progressbar=frametitle,numbering=fraction,sectionpage=none]{metropolis}
\IfFontExistsTF{Arial}{\setsansfont{Arial}}{\setsansfont{TeX Gyre Heros}}
\definecolor{ink}{HTML}{203E50}\definecolor{teal}{HTML}{288B73}
\setbeamercolor{normal text}{fg=ink,bg=white}
\setbeamercolor{frametitle}{fg=white,bg=ink}
\setbeamercolor{progress bar}{fg=teal,bg=ink!10}
\setbeamertemplate{navigation symbols}{}
\setbeamersize{text margin left=7mm,text margin right=7mm}
\setbeamerfont{frametitle}{size=\large,series=\bfseries}
\newcommand{\source}[1]{\vfill\par{\fontsize{6.5}{7.7}\selectfont\color{ink!70}#1}}
\begin{document}''']
for i,s in enumerate(slides):
 if i==0:deck.append(r'\begin{frame}[plain]{ }\vspace{2mm}{\LARGE\bfseries Water storage change across Thailand}\par\vspace{4mm}{\large\color{teal}A basin assessment of climate and the remaining residual}\par\vspace{8mm}{\large Farzeen Khan}\par\vspace{2mm}{\small MS in Water Engineering and Management\\Asian Institute of Technology}\par\vspace{5mm}{\small Advisor: Dr. Natthachet Tangdamrongsub}\end{frame}');continue
 deck.append(r'\begin{frame}{'+esc(s['title'])+'}')
 if s['figure']:
  stem=s['figure'];shutil.copy2(V/'figures'/(stem+'.pdf'),P/'figures'/(stem+'.pdf'));shutil.copy2(V/'figures'/(stem+'.png'),P/'figures'/(stem+'.png'))
  deck += [r'\begin{columns}[T]\begin{column}{.69\textwidth}\centering\includegraphics[width=\linewidth,height=.62\textheight,keepaspectratio]{figures/'+stem+r'.pdf}\end{column}\begin{column}{.28\textwidth}{\small\bfseries\color{teal}Interpretation}\par\vspace{2mm}{\fontsize{10.5}{13}\selectfont '+r'\par\vspace{3mm}'.join(esc(x) for x in s['interpretation'])+r'}\end{column}\end{columns}']
  # One concise definition is enough below the chart; detailed caveats are in the report.
  deck.append(r'\source{'+esc(s['section']+' · '+('All 22 basins are retained in the report and numerical tables.' if s['figure'] in ['scatter_six','seasonality'] else 'See the report for dates, sample counts and uncertainty.'))+'}')
 elif s['table']:
  n=len(s['table'][0]);deck += [r'\small\renewcommand{\arraystretch}{1.45}\begin{tabular}{'+''.join(r'>{\raggedright\arraybackslash}p{'+str(round(.9/n,3))+r'\textwidth}' for _ in range(n))+r'}\toprule']
  for j,row in enumerate(s['table']):deck.append(' & '.join(esc(x) for x in row)+r'\\'+(r'\midrule' if j==0 else ''))
  deck.append(r'\bottomrule\end{tabular}')
  if s['note']:deck.append(r'\source{'+esc(s['note'])+'}')
 else:
  deck.append(r'\begin{itemize}\setlength{\itemsep}{4mm}'+''.join(r'\item '+esc(x) for x in s['body'])+r'\end{itemize}')
  if s['note']:deck.append(r'\source{'+esc(s['note'])+'}')
 deck.append(r'\end{frame}')
deck.append(r'\end{document}');(P/'Thailand_Water_Storage_Seminar.tex').write_text('\n'.join(deck),encoding='utf-8');(P/'slides.json').write_text(json.dumps(slides,ensure_ascii=False,indent=2),encoding='utf-8')
(V/'qa/structure_contract.json').write_text(json.dumps({'report_pages':50,'results_pages':30,'results_percentage':60,'results_start':15,'results_end':44,'slides':32,'result_slides':19,'requested_order':['Introduction','Background','Problem statement','Objectives','Study area','Data collection','Methodology','Results','Conclusion','Discussion','Further work']},indent=2),encoding='utf-8')
print('50 report pages with 30 results pages; 32 slides with interpretation beside each results chart.')
