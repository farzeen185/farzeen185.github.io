"""Focused Metropolis seminar, using projection-sized scientific figures."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import json,shutil
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parents[1];V=R/'Thailand_Publication_v6';P=V/'presentation';F=P/'figures';F.mkdir(parents=True,exist_ok=True)
old=R/'Thailand_Research_v5/presentation/academic_metropolis';original=json.loads((old/'academic_slides.json').read_text(encoding='utf-8'));slides=[]
def existing(n):
 s=original['slides'][n-1].copy();s['backup']=False
 if s['figure']:
  for ext in ['png','pdf']:shutil.copy2(old/'figures'/(s['figure']+'.'+ext),F/(s['figure']+'.'+ext))
 slides.append(s)
def add(title,figure=None,lines=None,note='',section='ENSO',table=None,backup=False):slides.append({'title':title,'figure':figure,'lines':lines or [],'note':note,'section':section,'table':table,'equation':None,'layout':'standard','backup':backup})
for n in [1,2,3,4,6,7,9,10,11,13,15,17,18,20,21,25,22,24]:existing(n)
slides[0]['title']='Water storage change across Thailand';slides[0]['lines'][0]='Climate memory, ENSO and the credibility of human attribution'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':17,'axes.labelsize':17,'axes.titlesize':19,'xtick.labelsize':15,'ytick.labelsize':15,'axes.spines.top':False,'axes.spines.right':False})
def save(fig,stem):
 fig.tight_layout()
 for ext in ['png','pdf']:fig.savefig(F/(stem+'.'+ext),bbox_inches='tight',dpi=180)
 plt.close(fig)
en=pd.read_csv(V/'tables/ENSO_lagged_associations.csv',dtype={'region':str});q=en[(en.region=='TH')&(en['index']=='ONI')]
fig,axes=plt.subplots(1,2,figsize=(12.5,4.8),sharey=True)
for ax,var in zip(axes,['TWSA','GWSA']):
 for comp,color in [('Observed','#203a49'),('Climate','#368c83'),('Residual','#c46385')]:
  g=q[(q.variable==var)&(q.component==comp)];ax.plot(g.lag_months,g.partial_r,'o-',label=comp,color=color,lw=2,ms=6)
 ax.set_title(var);ax.set_xticks([0,3,6,9,12]);ax.set_xlabel('ONI lead (months)');ax.set_ylim(-.7,.4);ax.axhline(0,color='#999',lw=.8);ax.grid(axis='y',alpha=.15)
axes[0].set_ylabel('Season / trend / DMI adjusted r');axes[1].legend(frameon=False,fontsize=14,loc='lower left');save(fig,'enso_lags')
add('ENSO is clearer in the climate baseline than in the residual',figure='enso_lags',note='National 2003–2023 diagnostics. At six months, TWSA baseline r = −0.536 and residual r = −0.142; GWSA values are −0.528 and −0.136. These differences are descriptive, not a causal validation.')
add('ENSO evidence remains limited after multiple comparisons',lines=['All five selected leads and both ONI and historical RONI v5 are retained','No basin association passes the complete FDR screen','Only 21 years: minimum whole-year rotation p = 1/21','Weak residual correlation does not prove complete climate removal'],note='Circular whole-year rotations preserve index patterns but assume shift comparability. Contemporary DMI, calendar season and trend are controlled. Current operational RONI uses v6; the study freezes historical v5.')
phase=pd.read_csv(V/'tables/climate_skill_by_ENSO_phase.csv',dtype={'region':str});fig,axes=plt.subplots(1,2,figsize=(12.5,4.6))
for ax,var in zip(axes,['TWSA','GWSA']):
 g=phase[(phase.region=='TH')&(phase.variable==var)].set_index('phase').reindex(['El Nino','Neutral','La Nina']);ax.bar(range(3),g.RMSE_mm,color=['#c46385','#8a9a9f','#368c83'],width=.65);ax.set_xticks(range(3),['El Niño','Neutral','La Niña']);ax.set_title(var);ax.set_ylabel('Held-out RMSE (mm)')
 for i,(_,row) in enumerate(g.iterrows()):ax.text(i,row.RMSE_mm*1.03,f'n = {int(row.n)}',ha='center',fontsize=14)
 ax.set_ylim(0,g.RMSE_mm.max()*1.2)
save(fig,'enso_skill');add('Reconstruction skill varies with ENSO phase',figure='enso_skill',note='Frozen 2016–2023 ensemble, naturalized parent target. There are 29 El Niño, 31 La Niña and 36 neutral months. The months share events; these are conditional reconstruction scores, not independent event forecasts.')
for n in [28,30,33,34]:existing(n)
slides[-2]['note']='Interactive basin analysis, a consolidated figure library, final documents and runnable code: https://pratikkhanal16.github.io/thailand-water-storage-dss/'
slides[-1]['lines']=['National total and derived groundwater storage decline in the primary records','Weather memory improves parent-model reconstruction; ENSO diagnostics add context','Processing chains and monitoring support limit local rankings and attribution','The residual remains human effects plus unresolved discrepancy']
add('Selected references',lines=['Ji et al. (2025), climate / human separation. doi:10.1080/17538947.2025.2557516','Müller Schmied et al. (2024), WaterGAP. doi:10.5194/gmd-17-8817-2024','Chueasa et al. (2024), ENSO and Thai rainfall. doi:10.1016/j.mex.2024.102954','Sharifi et al. (2025), spatial response. doi:10.5194/hess-29-6985-2025','Mahto et al. (2025), MSEA-Res. doi:10.5194/essd-17-2693-2025'],note='Metropolis theme: Matthias Vogelgesang and contributors, https://github.com/matze/mtheme. Full source bibliography and frozen NOAA indices accompany the report.',section='References')
main=len(slides)
for n in [38,26,29,31,42,43,44,45]:
 existing(n);slides[-1]['backup']=True
(P/'academic_slides.json').write_text(json.dumps({'main_slides':main,'slides':slides},ensure_ascii=False,indent=2),encoding='utf-8')
# Reuse the already visually verified Metropolis layout, not its previous contents.
source=(R/'scripts/50_academic_metropolis.py').read_text(encoding='utf-8');tail=source[source.index('def esc(s):'):]
tail=tail.replace('Climate reconstruction and the limits of human attribution','Climate memory, ENSO and attribution credibility').replace('Thailand_Academic_Metropolis.tex','Thailand_Water_Storage_Seminar.tex')
exec(compile(tail,'verified_metropolis_layout','exec'),{'P':P,'slides':slides,'main':main,'json':json})
source=(R/'scripts/51_academic_powerpoint.mjs').read_text(encoding='utf-8').replace("Thailand_Research_v5/presentation/academic_metropolis","Thailand_Publication_v6/presentation").replace('Thailand_Academic_Metropolis.pptx','Thailand_Water_Storage_Seminar.pptx').replace('verified Thailand extended study, report and basin/forcing appendix','Thailand publication release, frozen ENSO diagnostics and verified component evidence').replace('26.1024.11018','26.1025.11240')
(R/'scripts/63_publication_powerpoint.mjs').write_text(source,encoding='utf-8')
print('Seminar:',main,'main +',len(slides)-main,'supporting slides.')
