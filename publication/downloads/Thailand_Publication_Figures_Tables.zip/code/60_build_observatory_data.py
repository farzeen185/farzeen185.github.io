"""Build the public dashboard from verified CSV outputs, preserving null values."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import json,shutil
import pandas as pd,numpy as np
from PIL import Image
R=Path(os.environ.get('TWSA_RESEARCH_ROOT',Path(__file__).resolve().parents[1])).resolve();V=R/'Thailand_Publication_v6';W=R/'Thailand_Objective3/web_app';P=W/'publication'
for p in [P/'data',P/'figures',P/'downloads']:p.mkdir(parents=True,exist_ok=True)
read=lambda n:pd.read_csv(V/'tables'/n,dtype={'region':str})
at=read('CSR_naturalized_attribution.csv');obs=read('CSR_basin_storage_timeseries.csv');pred=read('climate_emulator_timeseries.csv');land=read('GLDAS_matched_land_timeseries.csv');forcing=read('forcing_monthly_series_2003_2023.csv');head=read('annual_residual_groundwater_validation_series.csv')
tr=read('CSR_basin_trends.csv');ev=read('climate_emulator_validation.csv');ev=ev[(ev.model=='Ensemble')&(ev.period=='Test')];ci=read('attribution_wild_block_intervals.csv');ci=ci[ci.block_years==2];lm=read('GLDAS_matched_land_metrics.csv');en=read('ENSO_lagged_associations.csv');fs=read('forcing_summary_and_trends.csv');well=read('C07_basin_values.csv');rv=read('C08_basin_values.csv')
regions=[{'code':c,'name':n} for c,n in sorted(dict(zip(at.region,at.region_name)).items(),key=lambda z:(z[0]!='TH',z[0]))]
def clean(v):
 if isinstance(v,dict):return {k:clean(x) for k,x in v.items()}
 if isinstance(v,list):return [clean(x) for x in v]
 if isinstance(v,(np.integer,)):return int(v)
 if isinstance(v,(np.floating,float)):return float(v) if np.isfinite(v) else None
 return v
def records(df):return clean(df.to_dict('records'))
def series(df,fields):
 q=df[['date',*fields]].copy();q['date']=pd.to_datetime(q.date);q=q.set_index('date').sort_index()
 if q.empty:return []
 q=q.reindex(pd.date_range(q.index.min(),q.index.max(),freq='YS' if 'head_index' in fields else 'MS'));q.index.name='date';q=q.reset_index();q['date']=q.date.dt.strftime('%Y-%m-%d')
 return records(q)
data={'release':'26 October 2026','author':'Farzeen Khan','regions':regions,'basins':{},'indices':records(read('climate_indices_monthly.csv').query("date >= '2003-01-01' and date <= '2023-12-01'"))}
for r in regions:
 c=r['code'];b={}
 b['observed']=series(obs[obs.region==c],['TWSA','GWSA'])
 b['attribution']={v:series(at[(at.region==c)&(at.variable==v)],['observed_mm','climate_mm','modeled_human_mm','residual_mm','discrepancy_mm']) for v in ['TWSA','GWSA']}
 b['climate']={v:series(pred[(pred.region==c)&(pred.variable==v)&(pred.date>='2002-01-01')],['naturalized_target_mm','emulator_mm']) for v in ['TWSA','GWSA']}
 b['head']={v:series(head[(head.region==c)&(head.variable==v)],['head_index','residual_mm','matched_station_groups']) for v in ['TWSA','GWSA']}
 b['land']=series(land[land.region==c],['GLDAS_land_mm','naturalized_land_mm'])
 fields=['Native_P','Native_PET','CHIRPS_P','GLEAM_ET','MODIS_ET','ESA_CCI_SSM','ESA_CCI_RZSM','MODIS_LST']
 b['forcing']=series(forcing[forcing.region==c],fields)
 b['trends']={v:records(tr[(tr.region==c)&(tr.variable==v)])[0] for v in ['TWSA','GWSA']}
 b['skill']={v:records(ev[(ev.region==c)&(ev.variable==v)])[0] for v in ['TWSA','GWSA']}
 b['components']={v:{row['component']:row for row in records(ci[(ci.region==c)&(ci.variable==v)])} for v in ['TWSA','GWSA']}
 b['gldas']=records(lm[lm.region==c])[0];b['enso']=records(en[en.region==c]);b['forcing_means']={x['variable']:x['mean'] for x in records(fs[fs.region==c])}
 q=records(well[well.region==c]);b['wells']=q[0] if q else {};q=records(rv[rv.region==c]);b['reservoir']=q[0] if q else {}
 data['basins'][c]=b
(P/'data/observatory.json').write_text(json.dumps(clean(data),ensure_ascii=False,separators=(',',':'),allow_nan=False),encoding='utf-8')
cat=json.loads((V/'figure_catalog.json').read_text(encoding='utf-8'))
for x in cat:
 with Image.open(V/'figures'/(x['stem']+'.png')) as im:
  im.thumbnail((850,1050));im.convert('RGB').save(P/'figures'/(x['stem']+'.webp'),'WEBP',quality=88)
 x['image']='publication/figures/'+x['stem']+'.webp'
(P/'data/figures.json').write_text(json.dumps(cat,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
print('Dashboard:',len(regions),'regions;',len(cat),'unique figures; dataset',round((P/'data/observatory.json').stat().st_size/1e6,2),'MB.')
