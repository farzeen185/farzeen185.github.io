"""Readable evidence charts for the final report and seminar; no new model fits."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1';os.environ['MKL_NUM_THREADS']='1'
from pathlib import Path
import json,shutil,gc,textwrap
import numpy as np,pandas as pd,geopandas as gpd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize,TwoSlopeNorm
import matplotlib.dates as mdates
R=Path(__file__).resolve().parents[1];S=R/'Thailand_Publication_v6';V=R/'Thailand_Publication_v7';F=V/'figures';F.mkdir(parents=True,exist_ok=True)
read=lambda n:pd.read_csv(S/'tables'/n,dtype={'region':str})
obs=read('CSR_basin_storage_timeseries.csv');at=read('CSR_naturalized_attribution.csv');pr=read('climate_emulator_timeseries.csv');tr=read('CSR_basin_trends.csv');aux=read('forcing_monthly_series_2003_2023.csv');land=read('GLDAS_matched_land_timeseries.csv');heads=read('annual_residual_groundwater_validation_series.csv')
for d in [obs,at,pr,aux,land,heads]:d['date']=pd.to_datetime(d.date)
names=dict(zip(obs.region,obs.region_name));codes=sorted(c for c in names if c!='TH');selected=['01','04','05','10','19','22']
geo=gpd.read_file(R/'Thailand_Objective2/data/BASINS/MainBasin_ONWR_Law_WGS84.shp').to_crs(4326);geo['region']=geo.MB_CODE.astype(str).str.split('-').str[0].str.zfill(2);geo=geo.dissolve(by='region',as_index=False,aggfunc='first');geo.geometry=geo.geometry.simplify(.006,preserve_topology=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':13,'axes.labelsize':13,'axes.titlesize':14,'xtick.labelsize':11,'ytick.labelsize':11,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'savefig.facecolor':'white'})
colors={'obs':'#203e50','climate':'#33899b','emulator':'#c47a3e','residual':'#b95779','human':'#288b73','gap':'#8b879b'};catalog=[]
def save(fig,stem,title,caption,category):
 fig.tight_layout()
 # Vector PDFs are the publication masters. Raster previews stay modest in RAM.
 if not all((F/(stem+'.'+ext)).exists() and (F/(stem+'.'+ext)).stat().st_size>2000 for ext in ['pdf','png']):
  for ext in ['pdf','png']:fig.savefig(F/(stem+'.'+ext),bbox_inches='tight',dpi=180)
 plt.close(fig);gc.collect();catalog.append({'stem':stem,'title':title,'caption':caption,'category':category});print(stem,flush=True)
def copy(src,stem,title,caption,category):
 for ext in ['pdf','png']:shutil.copy2(src.with_suffix('.'+ext),F/(stem+'.'+ext))
 catalog.append({'stem':stem,'title':title,'caption':caption,'category':category})
def reindex(g,annual=False):
 g=g.set_index('date').sort_index();return g.reindex(pd.date_range(g.index.min(),g.index.max(),freq='YS' if annual else 'MS'))
def maps(stem,values,titles,units,caption,category,positive=False):
 fig,axes=plt.subplots(1,len(values),figsize=(4.2*len(values),5.8))
 for ax,val,title,unit in zip(np.atleast_1d(axes),values,titles,units):
  g=geo.merge(val.rename('value'),left_on='region',right_index=True,how='left');m=max(g.value.abs().max(),.001);pos=positive and g.value.min()>=0;norm=Normalize(0,m) if pos else TwoSlopeNorm(vmin=-m,vcenter=0,vmax=m);cm='viridis' if pos else 'RdBu'
  g.plot(column='value',ax=ax,cmap=cm,norm=norm,edgecolor='#71828a',linewidth=.4,missing_kwds={'color':'#ddd','hatch':'///'});ax.set_title(title);ax.set_xlabel('Longitude');ax.set_ylabel('Latitude');cb=fig.colorbar(plt.cm.ScalarMappable(norm=norm,cmap=cm),ax=ax,fraction=.04,pad=.025);cb.set_label(unit)
 save(fig,stem,' / '.join(titles),caption,category)
fig,ax=plt.subplots(2,1,figsize=(9,5.5),sharex=True)
for a,var in zip(ax,['TWSA','GWSA']):
 g=reindex(obs[obs.region=='TH']);a.plot(g.index,g[var],color=colors['obs'],lw=1.4);a.set_ylabel(var+' (mm)');a.axhline(0,color='#aaa',lw=.6);a.grid(axis='y',alpha=.15)
ax[-1].set_xlabel('Year');save(fig,'national_storage','National total and groundwater storage','TWSA uses the primary CSR record through September 2024; derived GWSA ends September 2023. Missing satellite months remain gaps. Negative anomalies mean storage below the 2004–2009 reference, not a negative absolute water volume.','Storage')
maps('storage_trends',[tr[tr.variable==v].set_index('region').sen_slope_mm_year for v in ['TWSA','GWSA']],['Total storage','Groundwater storage'],['Sen slope (mm/year)']*2,'Seasonal Sen slopes for all 22 basins. Negative rates indicate decline. Basin significance, intervals and sample counts are reported separately. All basins share broad GRACE support.','Storage')
def allbasins(stem,kind,var=None):
 for part,subset in enumerate([codes[:11],codes[11:]],1):
  fig,axes=plt.subplots(6,2,figsize=(9,11),sharex=True)
  for i,code in enumerate(subset):
   a=axes.ravel()[i]
   if kind=='observed':g=reindex(obs[obs.region==code]);series=[('TWSA','Total storage',colors['obs']),('GWSA','Groundwater',colors['climate'])]
   elif kind=='climate':g=reindex(pr[(pr.region==code)&(pr.variable==var)&(pr.date.dt.year>=2002)]);series=[('naturalized_target_mm','Naturalized parent',colors['climate']),('emulator_mm','Reconstruction',colors['emulator'])];a.axvspan(pd.Timestamp('2016-01-01'),pd.Timestamp('2023-12-31'),color='#298b7320')
   else:
    g=at[(at.region==code)&(at.date.dt.year<=2023)].pivot(index='date',columns='variable',values='residual_mm').reset_index();g=reindex(g);series=[('TWSA','Total-storage residual',colors['residual']),('GWSA','Groundwater residual',colors['obs'])]
   for col,label,color in series:a.plot(g.index,g[col],label=label,color=color,lw=1.1)
   a.set_title(code+' '+names[code][:24],loc='left',fontsize=12);a.tick_params(labelsize=10,labelbottom=True);a.xaxis.set_major_locator(mdates.YearLocator(10));a.xaxis.set_major_formatter(mdates.DateFormatter('%Y'));a.axhline(0,color='#aaa',lw=.5)
  axes.ravel()[-1].set_visible(False);handles,labels=axes.ravel()[0].get_legend_handles_labels();fig.legend(handles,labels,loc='lower right',bbox_to_anchor=(.98,.075),frameon=False,fontsize=12);fig.supylabel('Storage anomaly (mm)',fontsize=14)
  caption=('All basins are shown across two pages to keep labels legible. '+('Shading marks the held-out test years 2016–2023. The parent is naturalized WaterGAP, not observed climate-only storage.' if kind=='climate' else 'Real observation gaps remain missing. The residual is observed minus the naturalized baseline and includes unresolved discrepancy.' if kind=='residual' else 'Total and derived groundwater anomalies have different component definitions and record endpoints.'))
  save(fig,f'{stem}_{part}',f'{kind.capitalize()} histories for basins '+('01–11' if part==1 else '12–22'),caption,'Storage' if kind=='observed' else kind.capitalize())
allbasins('observed','observed');allbasins('climate_TWSA','climate','TWSA');allbasins('climate_GWSA','climate','GWSA');allbasins('residual','residual')
fs=read('forcing_summary_and_trends.csv');maps('forcing_maps',[fs[fs.variable==c].set_index('region')['mean'] for c in ['Native_P','Native_PET','CHIRPS_P']],['Native rainfall','Potential ET','CHIRPS rainfall'],['mm/month']*3,'Available-month means, 2003–2023. Native rainfall and PET drive the reconstruction; CHIRPS supplies alternative rainfall. Monthly fluxes are distinct from storage anomalies.','Forcing',True)
fig,axes=plt.subplots(3,2,figsize=(9,7.4))
for ax,code in zip(axes.ravel(),selected):
 g=aux[aux.region==code];q=obs[(obs.region==code)&obs.date.dt.year.between(2003,2023)];bp=ax.boxplot([g[g.date.dt.month==m].Native_P.dropna() for m in range(1,13)],positions=range(1,13),patch_artist=True,showfliers=False,manage_ticks=False,widths=.5)
 for box in bp['boxes']:box.set(facecolor='#d4e8ec',edgecolor=colors['climate'])
 for med in bp['medians']:med.set(color=colors['climate'])
 b=ax.twinx();s=q.groupby(q.date.dt.month).TWSA.mean();b.plot(s.index,s,color=colors['residual'],lw=1.7);b.tick_params(colors=colors['residual'],labelsize=10);ax.set_xticks([1,4,7,10]);ax.set_title(code+' '+names[code],loc='left',fontsize=12);ax.set_ylabel('Rainfall (mm)');b.set_ylabel('TWSA (mm)',color=colors['residual'])
save(fig,'seasonality','Rainfall and storage seasonal timing','Six geographically distributed illustrative basins; all 22 remain in the numerical release. Boxes show interannual native rainfall by month (quartiles and 1.5-IQR whiskers; outliers suppressed); pink line is mean observed TWSA on its own right-hand axis. Distribution spread is not a confidence interval.','Forcing')
fig,axes=plt.subplots(2,1,figsize=(9,5.5),sharex=True)
for ax,var in zip(axes,['TWSA','GWSA']):
 g=reindex(pr[(pr.region=='TH')&(pr.variable==var)&pr.date.dt.year.between(2002,2023)]);ax.plot(g.index,g.naturalized_target_mm,label='Naturalized parent',color=colors['climate'],lw=1.4);ax.plot(g.index,g.emulator_mm,label='Weather reconstruction',color=colors['emulator'],lw=1,ls='--');ax.axvspan(pd.Timestamp('2016-01-01'),pd.Timestamp('2023-12-31'),color='#298b7320');ax.set_ylabel(var+' (mm)')
axes[0].legend(frameon=False,ncol=2,fontsize=11);axes[-1].set_xlabel('Year');save(fig,'climate_national','Weather reconstruction of naturalized storage','The shaded years 2016–2023 were excluded from training and model selection. Close curves show reconstruction of the parent model; they do not independently establish the true natural climate counterfactual.','Climate')
fig,axes=plt.subplots(3,2,figsize=(9,7.4))
for ax,code in zip(axes.ravel(),selected):
 q=pr[(pr.region==code)&(pr.variable=='TWSA')&pr.date.dt.year.between(2016,2023)].dropna();x=q.emulator_mm.to_numpy();y=q.naturalized_target_mm.to_numpy();xx=np.array([min(x.min(),y.min()),max(x.max(),y.max())]);ax.scatter(x,y,s=12,c='#29b8d0',alpha=.7,edgecolors='none');ax.plot(xx,xx,c='#999',lw=.8,ls='--');ax.plot(xx,np.polyval(np.polyfit(x,y,1),xx),c=colors['residual'],lw=1.2);rmse=np.sqrt(np.mean((x-y)**2));nse=1-np.sum((x-y)**2)/np.sum((y-y.mean())**2);ax.text(.96,.06,f'r = {np.corrcoef(x,y)[0,1]:.2f}\nRMSE = {rmse:.1f} mm\nNSE = {nse:.2f}',transform=ax.transAxes,ha='right',fontsize=10,bbox={'fc':'white','ec':'#aaa','lw':.4});ax.set_title(code+' '+names[code],loc='left',fontsize=12);ax.set_xlabel('Reconstruction (mm)');ax.set_ylabel('Parent target (mm)');ax.grid(alpha=.17)
save(fig,'scatter_six','Held-out TWSA reconstruction agreement','2016–2023 test months, six geographical examples. Grey is identity; pink is a descriptive fit. Metrics compare predictions directly with the parent target. Basin selection is geographic, not based on model performance; all 22 basin metrics are provided.','Climate')
ev=read('climate_emulator_validation.csv');ev=ev[(ev.model=='Ensemble')&(ev.period=='Test')]
maps('climate_skill_maps',[ev[ev.variable==v].set_index('region').deseasonalized_NSE for v in ['TWSA','GWSA']],['Total-storage anomaly skill','Groundwater anomaly skill'],['Held-out anomaly NSE']*2,'NSE compares squared error with the target-mean benchmark; 1 is perfect, 0 equals that benchmark and negative is worse. Monthly climatology comes only from training. The target is naturalized WaterGAP.','Climate',True)
fig,ax=plt.subplots(figsize=(9,4.6));g=reindex(land[land.region=='TH']);ax.plot(g.index,g.GLDAS_land_mm,label='GLDAS Noah',color=colors['obs'],lw=1.3);ax.plot(g.index,g.naturalized_land_mm,label='WaterGAP matching land',color=colors['emulator'],lw=1.2);ax.set(xlabel='Year',ylabel='Soil + canopy + snow anomaly (mm)');ax.legend(frameon=False,ncol=2,fontsize=11);save(fig,'gldas_national','Matching land-storage histories','This comparison excludes groundwater and open surface water. GLDAS is a cross-model benchmark, not an observed total-storage or human-only validation dataset.','GLDAS')
lm=read('GLDAS_matched_land_metrics.csv');maps('gldas_maps',[lm.set_index('region').NSE,lm.set_index('region').RMSE_mm],['Land-storage NSE','Land-storage RMSE'],['NSE','RMSE (mm)'],'Matching soil, canopy and snow compartments on paired dates. Higher NSE and lower RMSE mean closer model agreement for this same target. They do not validate the residual.','GLDAS',True)
fig,axes=plt.subplots(2,1,figsize=(9,5.4),sharex=True)
for ax,var in zip(axes,['TWSA','GWSA']):
 g=reindex(at[(at.region=='TH')&(at.variable==var)])
 for col,label,color in [('residual_mm','Residual',colors['residual']),('modeled_human_mm','Model human effect',colors['human']),('discrepancy_mm','Unexplained gap',colors['gap'])]:ax.plot(g.index,g[col],label=label,color=color,lw=1.3)
 ax.set_ylabel(var+' (mm)');ax.axhline(0,color='#999',lw=.5)
axes[0].legend(frameon=False,ncol=3,fontsize=10);axes[-1].set_xlabel('Year');save(fig,'residual_national','Residual compared with the modeled human effect','Residual = observed − naturalized. Modeled human effect = historical − naturalized. Unexplained gap = observed − historical. Thus residual = modeled human effect + unexplained gap. A negative residual is not measured pumping.','Residual')
ci=read('attribution_wild_block_intervals.csv');ci=ci[(ci.block_years==2)&(ci.component=='residual_mm')];maps('residual_maps',[ci[ci.variable==v].set_index('region').ols_slope_mm_year for v in ['TWSA','GWSA']],['Total-storage residual','Groundwater residual'],['OLS trend (mm/year)']*2,'Calendar-month fixed-effect OLS on common available dates. These additive rates differ from the primary seasonal Sen estimates. Residuals include human effects and observation/model discrepancy.','Residual')
mad=read('annual_variability_ratios.csv');fig,axes=plt.subplots(2,1,figsize=(9,5),sharex=True)
for ax,var in zip(axes,['TWSA','GWSA']):
 q=mad[(mad.region=='TH')&(mad.variable==var)];ax.plot(q.year,q.climate_MAD_ratio,'o-',ms=4,color=colors['climate'],label='Climate variability / observed');ax.plot(q.year,q.residual_MAD_ratio,'o-',ms=4,color=colors['residual'],label='Residual variability / observed');ax.axhline(1,color='#999',ls='--',lw=.7);ax.set_ylabel(var+' ratio')
axes[0].legend(frameon=False,fontsize=10,ncol=2);axes[-1].set_xlabel('Year');save(fig,'variability','How climate and residual variability change over time','Annual mean absolute deviations on the same available months (minimum eight). Ratios need not sum to one and may exceed one because components covary. These are not climate/human percentages.','Residual')
for src,stem,title,caption,cat in [(R/'Thailand_Research_v5/presentation/figures/05_product_ranking_scatter','product_ranks','Processing-chain sensitivity','Common-date basin trends differ across CSR and COST-G/G3P. Rank correlations are 0.138 for TWSA and 0.027 for GWSA; both gravity and compartment processing differ.','Storage'),(R/'Thailand_Research_v5/presentation/figures/13_climate_memory_ablation','memory','Weather memory improves reconstruction','Controlled Ridge comparison; boxplots describe basin variation, not confidence intervals. National test anomaly NSE improves from 0.283 to 0.890 for TWSA and 0.039 to 0.723 for GWSA.','Climate'),(R/'Thailand_Research_v5/presentation/academic_metropolis/figures/annual_skill','annual_skill','Skill changes between test years','National annual anomaly NSE against the naturalized parent. The 2022 groundwater score is −1.067 and is retained; pooled scores hide this failure.','Climate'),(R/'Thailand_Publication_v6/presentation/figures/enso_lags','enso_lags','ENSO timing in storage components','National partial correlations remove season, trend and contemporaneous DMI, 2003–2023. All five selected ENSO leads are shown. The residual has a weaker six-month association, but this does not prove complete climate removal.','ENSO'),(R/'Thailand_Publication_v6/presentation/figures/enso_skill','enso_skill','Model reconstruction during ENSO phases','Held-out parent reconstruction, with 29 El Niño, 36 neutral and 31 La Niña months. Months share events; this is not independent event prediction.','ENSO'),(R/'Thailand_Research_v5/presentation/academic_metropolis/figures/reservoir_national','reservoir','Independent reservoir component evidence','Scene-supported values, with season and trend removed, then standardized. Points preserve observation gaps. Adjusted national r = 0.439 across 73 months; year-cluster 95% interval 0.188–0.665.','Validation'),(R/'Thailand_Research_v5/presentation/academic_metropolis/figures/head_spatial','head_maps','Groundwater consistency and its spatial limits','Annual residual–head correlations. Hatching indicates inadequate support. Head and basin storage have different units and observation scales; no storage-volume validation is implied.','Validation')]:copy(src,stem,title,caption,cat)
fig,axes=plt.subplots(3,2,figsize=(9,7.4),sharex=True)
for ax,code in zip(axes.ravel(),selected):
 q=heads[(heads.region==code)&(heads.variable=='GWSA')].dropna(subset=['head_index','residual_mm']);q=q.set_index('date');grid=pd.date_range('2002-01-01','2023-01-01',freq='YS');z=pd.DataFrame(index=grid)
 for col in ['head_index','residual_mm']:z[col]=((q[col]-q[col].mean())/q[col].std(ddof=0)) if len(q)>1 else np.nan
 for col,label,color in [('head_index','Head',colors['obs']),('residual_mm','Groundwater residual',colors['residual'])]:ax.plot(z.index,z[col],'o-',lw=1,ms=3,label=label,color=color)
 ax.set_title(code+' '+names[code],loc='left',fontsize=12);ax.set_ylabel('Standardized anomaly');ax.tick_params(labelsize=10);ax.axhline(0,color='#aaa',lw=.5)
axes[0,0].legend(frameon=False,fontsize=10);save(fig,'head_histories','Groundwater levels and groundwater residual timing','Six geographical examples on jointly available annual support. Standardization permits a timing comparison but does not convert head into groundwater volume. Short samples and changing stations limit inference; gaps remain missing.','Validation')
copy(R/'Thailand_Research_v5/presentation/figures/01_study_basins','study_area','Thailand principal basins','The 22 ONWR basins are reporting polygons. Adjacent basins share broad GRACE support.','Methods')
for i,x in enumerate(catalog,1):x['id']=i
(V/'figure_catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2),encoding='utf-8');print('Readable chart set:',len(catalog))
