"""Consolidate verified science and original figures without deleting inputs."""
from pathlib import Path
import os,json,shutil,csv,hashlib,requests
R=Path(os.environ.get('TWSA_RESEARCH_ROOT',Path(__file__).resolve().parents[1])).resolve();O=R/'Thailand_Research_v5';V=R/'Thailand_Publication_v6'
catalog=[]
def add(src,stem,title,caption,category):
 for ext in ['png','pdf']:
  dst=V/'figures'/(stem+'.'+ext)
  if src.with_suffix('.'+ext).resolve()!=dst.resolve():shutil.copy2(src.with_suffix('.'+ext),dst)
 catalog.append({'id':len(catalog)+1,'stem':stem,'title':title,'caption':caption,'category':category})
for x in json.loads((V/'figure_inventory.json').read_text(encoding='utf-8')):
 add(V/'figures'/x['stem'],x['stem'],x['title'],x['caption'],'ENSO' if x['id']>=7 else 'Reconstruction')
for x in json.loads((O/'figure_revision/figure_inventory.json').read_text(encoding='utf-8')):
 add(O/'figure_revision/figures'/Path(x['file']).stem,Path(x['file']).stem,x['title'],x['caption'],'Storage' if x['id']<=2 else 'Climate' if x['id']<=5 or x['id'] in [13,14] else 'Residual' if x['id']<=8 else 'GLDAS' if x['id']<=12 else 'Validation')
for x in json.loads((O/'basin_forcing_appendix/figure_inventory.json').read_text(encoding='utf-8')):
 if x['id'] in [1,3,5,6,7,8,9,10]:
  add(O/'basin_forcing_appendix/figures'/Path(x['file']).stem,Path(x['file']).stem,x['title'],x['note'],'Forcing')
for stem,title,caption in [('01_study_basins','Thailand principal basins','The 22 ONWR principal basins. Administrative reporting polygons do not create independent GRACE resolution.'),('05_product_ranking_scatter','Processing-chain sensitivity','Common-date comparison of CSR and COST-G/G3P chains. Basin trend-ranking agreement is weak: Spearman 0.138 for TWSA and 0.027 for GWSA. Gravity and compartment processing differ, so groundwater contrasts cannot be attributed solely to GRACE.'),('13_climate_memory_ablation','Climate memory ablation','Controlled Ridge experiment: current weather compared with weather-memory predictors; same training, validation and test splits. National test anomaly NSE rises from 0.283 to 0.890 for TWSA and 0.039 to 0.723 for GWSA.')]:
 add(O/'presentation/figures'/stem,stem,title,caption,'Methods')
for stem,title,caption in [('forcing_national','National precipitation and potential ET','Native rainfall and PET drive the emulator. CHIRPS is independent alternative rainfall; native P/PET monthly totals use actual calendar month lengths.'),('reservoir_national','Independent reservoir component evidence','Scene-supported national reservoir and TWS residual anomalies after removing season and trend, then standardizing. Points retain missing scene support; no gap interpolation. r = 0.439 across 73 paired months; year-cluster interval 0.188–0.665.')]:
 add(O/'presentation/academic_metropolis/figures'/stem,stem,title,caption,'Forcing' if stem.startswith('forcing') else 'Validation')
(V/'figure_catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2),encoding='utf-8')
for folder in [O/'tables',O/'figure_revision/tables',O/'basin_forcing_appendix/tables']:
 for p in folder.glob('*.csv'):
  dst=V/'tables'/p.name
  if dst.exists():assert hashlib.sha256(dst.read_bytes()).digest()==hashlib.sha256(p.read_bytes()).digest(),p.name
  else:shutil.copy2(p,dst)
for name in ['climate_emulator_timeseries.csv','climate_emulator_validation.csv','climate_emulator_weights.csv']:
 shutil.copy2(R/'Thailand_Objective2/analysis_v4/tables'/name,V/'tables'/name)
refs=[]
meta=json.loads((O/'logs/bibliographic_metadata.json').read_text(encoding='utf-8'))
new=['10.1080/17538947.2025.2557516','10.1016/j.mex.2024.102954','10.1016/j.jhydrol.2021.126868','10.5194/hess-29-6985-2025','10.5194/gmd-17-8817-2024','10.5194/essd-17-2693-2025']
for doi in new:
 m=meta.get(doi,{})
 if not m.get('title'):
  try:
   q=requests.get('https://api.crossref.org/works/'+doi,timeout=25);q.raise_for_status();m=q.json()['message']
  except requests.RequestException:m={'title':[doi]}
 authors=m.get('author',[]);auth=', '.join(x.get('family',x.get('name','')) for x in authors[:4])+(' et al.' if len(authors)>4 else '')
 year=m.get('published',{}).get('date-parts',[[None]])[0][0]
 refs.append({'doi':doi,'authors':auth,'year':year,'title':m['title'][0],'journal':(m.get('container-title') or [''])[0],'url':'https://doi.org/'+doi,'metadata':m})
(V/'literature_sources.json').write_text(json.dumps(refs,ensure_ascii=False,indent=2),encoding='utf-8')
print('Consolidated',len(catalog),'unique figures and',len(list((V/'tables').glob('*.csv'))),'tables.')
