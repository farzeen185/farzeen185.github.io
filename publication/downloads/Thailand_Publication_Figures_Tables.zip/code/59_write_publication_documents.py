"""Author a concise 50-page AIT-style report and a separate journal manuscript."""
from pathlib import Path
import os,json,csv,math,hashlib
from copy import deepcopy
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH as A
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from PIL import Image
from v6_research_text import TITLE,SUBTITLE,AUTHOR,ABSTRACT,SECTIONS
R=Path(os.environ.get('TWSA_RESEARCH_ROOT',Path(__file__).resolve().parents[1])).resolve();V=R/'Thailand_Publication_v6'
catalog=json.loads((V/'figure_catalog.json').read_text(encoding='utf-8')); C={x['stem']:x for x in catalog}
for name in ['report','manuscript','qa']: (V/name).mkdir(exist_ok=True)
def csvread(n):
 with (V/'tables'/n).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def fmt(x,c=''):
 try:v=float(x)
 except (ValueError,TypeError):return x if x else '—'
 if not math.isfinite(v):return '—'
 if c=='region':return str(x)
 if c=='n' or c.endswith('_n') or c.endswith('_years'):return str(int(v))
 if c.endswith('_q'):return '<.001' if v<.001 else f'{v:.3f}'
 return f'{v:.3f}' if 'NSE' in c or c=='r' or '_r' in c else f'{v:.2f}'
class Writer:
 def __init__(self,title):
  self.d=Document(R/'reports/AIT_official_template.docx');sp=deepcopy(self.d.sections[0]._sectPr)
  for child in list(self.d._element.body):self.d._element.body.remove(child)
  self.d._element.body.append(sp);self.pages=[];self.nfig=0;self.ntab=0
  self.d.core_properties.author=AUTHOR;self.d.core_properties.title=title;self.d.core_properties.subject='Thailand water storage climate attribution and independent evidence'
  for name in ['Normal','Title','Heading 1','Heading 2','Heading 3','Caption']:
   s=self.d.styles[name];s.font.name='Times New Roman';s.font.size=Pt(12);s.font.color.rgb=RGBColor(0,0,0);s.paragraph_format.page_break_before=False
  self.d.styles['Title'].font.size=Pt(16);self.d.styles['Heading 1'].font.size=Pt(14)
  sec=self.d.sections[0];sec.different_first_page_header_footer=True
  for hf in [sec.header,sec.footer,sec.first_page_header,sec.first_page_footer,sec.even_page_header,sec.even_page_footer]:
   for child in list(hf._element):hf._element.remove(child)
   hf.add_paragraph()
  pg=sec._sectPr.find(qn('w:pgNumType'))
  if pg is None:pg=OxmlElement('w:pgNumType');sec._sectPr.append(pg)
  pg.set(qn('w:fmt'),'decimal');pg.set(qn('w:start'),'1')
  p=sec.footer.paragraphs[0];p.alignment=A.CENTER;r=p.add_run();fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');r._r.addnext(fld)
 def para(self,s='',size=12,bold=False,align=A.JUSTIFY,spacing=1.5,after=6,style=None):
  p=self.d.add_paragraph(style=style);p.alignment=align;pf=p.paragraph_format;pf.line_spacing=spacing;pf.space_before=Pt(0);pf.space_after=Pt(after);pf.widow_control=True
  # Clear inherited list numbering from the official template.
  np=OxmlElement('w:numPr');ni=OxmlElement('w:numId');ni.set(qn('w:val'),'0');np.append(ni);p._p.get_or_add_pPr().append(np)
  r=p.add_run(s);r.font.name='Times New Roman';r.font.size=Pt(size);r.font.color.rgb=RGBColor(0,0,0);r.bold=bold;return p
 def heading(self,s,level=2):
  p=self.para(s,14 if level==1 else 12,True,A.CENTER if level==1 else A.LEFT,1,10,'Heading '+str(level));p.paragraph_format.keep_with_next=True;return p
 def page(self,s,chapter=None):
  self.pages.append({'page':len(self.pages)+1,'title':s});p=self.heading(('CHAPTER '+str(chapter)+'\n'+s.upper()) if chapter else s,1 if chapter else 2)
  if len(self.pages)>1:p.paragraph_format.page_break_before=True
 def text(self,key,indices=None):
  for s in SECTIONS[key] if indices is None else [SECTIONS[key][i] for i in indices]:self.para(s)
 def fig(self,stem,h=5.55,note=True):
  self.nfig+=1;x=C[stem];p=self.para('',align=A.CENTER,spacing=1,after=2);p.paragraph_format.keep_with_next=True
  with Image.open(V/'figures'/(stem+'.png')) as im:w,ht=im.size
  p.add_run().add_picture(str(V/'figures'/(stem+'.png')),width=Inches(min(6.05,h*w/ht)))
  p=self.para(f'Figure {self.nfig}  '+x['title'],size=11,bold=True,align=A.CENTER,spacing=1.05,after=5);p.paragraph_format.keep_with_next=note
  if note:self.para(x['caption'],size=10.5,spacing=1.1,after=7)
 def table(self,title,headers,rows,font=10):
  self.ntab+=1;p=self.para(f'Table {self.ntab}  '+title,size=11,bold=True,align=A.CENTER,spacing=1.1);p.paragraph_format.keep_with_next=True
  t=self.d.add_table(rows=1,cols=len(headers));t.autofit=False
  for c,s in zip(t.rows[0].cells,headers):c.text=s
  repeat=OxmlElement('w:tblHeader');t.rows[0]._tr.get_or_add_trPr().append(repeat)
  for row in rows:
   for c,s in zip(t.add_row().cells,row):c.text=str(s)
  for i,row in enumerate(t.rows):
   for c in row.cells:
    c.width=Inches(6.05/len(headers));pr=c._tc.get_or_add_tcPr();b=OxmlElement('w:tcBorders')
    for side in ['top','bottom']:
     e=OxmlElement('w:'+side);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'4');e.set(qn('w:color'),'999999');b.append(e)
    pr.append(b)
    for p in c.paragraphs:
     p.alignment=A.LEFT;p.paragraph_format.line_spacing=1;p.paragraph_format.space_before=Pt(2);p.paragraph_format.space_after=Pt(2)
     for r in p.runs:r.font.name='Times New Roman';r.font.size=Pt(font);r.bold=i==0
  return t
 def basin_table(self,k):
  inv=json.loads((R/'Thailand_Research_v5/basin_forcing_appendix/table_inventory.json').read_text(encoding='utf-8'));x=next(x for x in inv if x['id']==k);g=csvread(x['file'])
  self.table(x['title'],x['headers'],[[fmt(z[c],c) for c in x['columns']] for z in g],9.5);self.para(x['note'],size=10.5,spacing=1.1)
 def save(self,p):
  self.d.save(p);return {'path':str(p),'intended_pages':self.pages,'figures':self.nfig,'tables':self.ntab}

refs=[]
for x in json.loads((V/'literature_sources.json').read_text(encoding='utf-8')):
 refs.append(f"{x['authors']} ({x['year']}). {x['title']}. {x['journal']}. {x['url']}")
refs += [
'Save, H., Bettadpur, S., and Tapley, B. D. (2016). High-resolution CSR GRACE RL05 mascons. Journal of Geophysical Research Solid Earth. https://doi.org/10.1002/2016JB013007',
'CSR (2026). GRACE and GRACE-FO RL06.3 mascon solutions and processing guidance. https://www2.csr.utexas.edu/grace/RL0603_mascons.html',
'Güntner, A., et al. (2024). Global Gravity-based Groundwater Product G3P version 1.12. https://doi.org/10.5880/G3P.2024.001',
'Bäthge, A., et al. (2026). GROW global groundwater time series dataset. https://doi.org/10.5281/zenodo.15149480',
'NOAA CPC (2026). Historical Oceanic Niño Index and Relative Oceanic Niño Index version 5. Frozen index data and download URLs accompany the release. https://www.cpc.ncep.noaa.gov/products/analysis_monitoring/enso/oni/v5/',
'NOAA PSL (2026). HadISST Dipole Mode Index monthly time series. https://psl.noaa.gov/data/timeseries/month/DMI/',
'NASA (n.d.). GLDAS dataset specifications. https://ldas.gsfc.nasa.gov/gldas/dataset',
'Mann, H. B. (1945). Nonparametric tests against trend. Econometrica, 13, 245–259. https://doi.org/10.2307/1907187',
'Sen, P. K. (1968). Estimates of the regression coefficient based on Kendall’s tau. JASA, 63, 1379–1389. https://doi.org/10.1080/01621459.1968.10480934',
'Benjamini, Y., and Hochberg, Y. (1995). Controlling the false discovery rate. JRSS B, 57, 289–300. https://doi.org/10.1111/j.2517-6161.1995.tb02031.x'
]

w=Writer(TITLE)
w.pages.append({'page':1,'title':'Title page'})
w.para(TITLE.upper(),size=16,bold=True,align=A.CENTER,spacing=1.3,after=20,style='Title');w.para(SUBTITLE,align=A.CENTER,after=35)
w.para('by',align=A.CENTER);w.para(AUTHOR,bold=True,align=A.CENTER,after=35)
w.para('Master of Science in Water Engineering and Management',align=A.CENTER);w.para('Asian Institute of Technology',align=A.CENTER,after=30)
w.para('Advisor  Dr. Natthachet Tangdamrongsub',align=A.CENTER,after=35);w.para('Research report\nOctober 2026',align=A.CENTER)
w.page('Abstract');w.para(ABSTRACT);w.para('Keywords  GRACE groundwater storage climate memory ENSO Thailand attribution uncertainty',size=11,spacing=1.2)
w.page('Contents')
for title,p in [('Abstract',2),('Abbreviations and reading guide',4),('Chapter 1 Introduction and research contribution',5),('Chapter 2 Study area and datasets',8),('Chapter 3 Methodology',10),('Chapter 4 Results',18),('Storage trends and product sensitivity',18),('Forcing and climate reconstruction',22),('GLDAS and residual comparisons',34),('ENSO diagnostics',41),('Independent groundwater and reservoir evidence',44),('Chapter 5 Discussion',48),('Chapter 6 Conclusions and reproducibility',49),('References',50)]:w.para(f'{title}     {p}',align=A.LEFT,spacing=1.3,after=7)
w.para('Basin codes, full numerical tables and vector figures are supplied with the report. The website provides one searchable figure collection and full-precision CSV downloads.',spacing=1.3)
w.page('Abbreviations and reading guide')
w.table('Principal quantities',['Symbol','Meaning'],[['TWSA','Terrestrial water storage anomaly'],['GWSA','Groundwater storage anomaly'],['O','Observed TWSA or compartment-derived GWSA'],['C','Naturalized WaterGAP baseline'],['A','Historical WaterGAP with represented human activities'],['R = O − C','Residual relative to the baseline'],['H = A − C','Human effect represented by the paired model'],['E = O − A','Unresolved observation–historical-model discrepancy'],['ONI / RONI','Oceanic / Relative Oceanic Niño Index'],['DMI','Dipole Mode Index for the Indian Ocean Dipole'],['NSE / RMSE','Nash–Sutcliffe efficiency / root mean square error'],['FDR q','Multiple-comparison adjusted probability measure']],10.5)
w.para('Read the observed trend, climate-model score and independent component evidence as separate results. In particular, R = H + E; the residual is not a measured pumping record. Missing data are shown as gaps or unavailable values. Different record lengths and evaluation targets are stated at each comparison.')
w.page('Introduction',1);w.text('Introduction')
w.page('Literature and research gap');w.text('Literature and research gap')
w.page('Contribution and research objectives');w.text('Contribution and hypotheses')
w.page('Study area',2);w.fig('01_study_basins',4.5);w.text('Study area and reporting scale',[2])
w.page('Datasets and observation support');w.table('Data roles and limitations',['Input','Role','Important limit'],[['CSR RL06.3','Observed total storage','Broad native gravity support'],['GLDAS Noah','Soil canopy and snow','Partial land storage only'],['G3P surface water','Groundwater subtraction','Modeled component uncertainty'],['WaterGAP paired runs','Naturalized and historical baseline','Model-defined counterfactual'],['Native P and PET','Emulator predictors','Native forcing dependence'],['CHIRPS and other satellites','Alternative forcing and context','Unequal spatial and temporal coverage'],['GROW well archive','Head comparison','Mostly annual local observations'],['MSEA-Res Level 1','Reservoir component check','Sparse scene-supported months'],['ONI RONI v5 and DMI','Teleconnection diagnostics','Short record and version sensitivity']],10);w.text('Data and provenance',[2])
for title,key,chapter in [('Harmonization and missing data','Common units reference and missing data',3),('Groundwater storage calculation','Groundwater storage balance',None),('Trend estimation and significance','Trends and significance',None),('Climate reconstruction and test design','Climate reconstruction design',None),('Residual accounting and variability','Residual and represented human effect',None),('Evaluation using GLDAS wells and reservoirs','Evaluation and independent evidence',None),('ENSO and IOD methodology','ENSO and IOD diagnostics',None),('Uncertainty and reproducibility','Uncertainty and reproducibility',None)]:w.page(title,chapter);w.text(key)
w.page('Observed storage trends',4);w.fig('A01_observed_spatial',4.6);w.text('Storage results',[0])
w.page('Observed storage in every basin');w.fig('A02_observed_temporal_all_basins',6.9)
w.page('Basin trend values');w.basin_table(1);w.text('Storage results',[2])
w.page('Sensitivity to the processing chain');w.fig('05_product_ranking_scatter',4.5);w.text('Storage results',[1])
w.page('Meteorological inputs in space and time');w.fig('D01_forcing',4.0);w.fig('forcing_national',2.1)
w.page('GLDAS and residual spatial comparison');w.fig('A11_gldas_residual_spatial',5.7);w.para('This comparison deliberately standardizes quantities with different component definitions. Correlated timing can indicate shared climate or model dependence; it cannot establish equal water volume or validate anthropogenic storage. GLDAS contributes to GWS subtraction, so independence is especially limited for the groundwater residual.')
w.page('Rainfall and storage seasonality');w.fig('P04_monthly_seasonality',6.9)
w.page('Climate baseline and reconstruction maps');w.fig('A03_climate_spatial',5.7);w.para('C is the naturalized WaterGAP baseline, while the emulator is a weather-based approximation of that parent. Their slopes are calculated on stated comparable support. The baseline used in the primary residual is not silently replaced by the statistical prediction. This distinction separates hydrological counterfactual uncertainty from reconstruction error.')
w.page('TWSA reconstruction in every basin');w.fig('A04_climate_TWSA_temporal',6.9)
w.page('GWSA reconstruction in every basin');w.fig('A05_climate_GWSA_temporal',6.9)
w.page('Held out TWSA reconstruction scatterplots');w.fig('P01_climate_TWSA_scatter',6.9)
w.page('Held out GWSA reconstruction scatterplots');w.fig('P02_climate_GWSA_scatter',6.9)
w.page('TWSA reconstruction performance by basin');w.basin_table(2);w.text('Climate and GLDAS results',[0])
w.page('GWSA reconstruction performance by basin');w.basin_table(3);w.para('The target remains the modeled naturalized groundwater baseline. The scores do not directly validate derived GRACE groundwater or pumping. Test dates are excluded from fitting and ensemble-weight selection; climate-memory predictors use preceding meteorological information. Full annual metrics and forcing-ablation results remain downloadable.')
w.page('Spatial climate model performance');w.fig('A13_climate_evaluation_spatial',5.8);w.para('Raw NSE can be high when a model captures the annual cycle. Anomaly NSE is therefore a required companion, with the monthly reference learned from training. The map includes both TWSA and GWSA and preserves negative skill. A good score against a parent model is a reconstruction result, not proof that its naturalized baseline is observationally correct.')
w.page('Time varying climate skill and memory');w.fig('A14_climate_evaluation_temporal',3.2);w.fig('13_climate_memory_ablation',2.3);w.text('Climate and GLDAS results',[1])
w.page('GLDAS spatial land storage benchmark');w.fig('A09_gldas_spatial',4.4);w.text('Climate and GLDAS results',[2])
w.page('GLDAS matched compartment scatterplots');w.fig('P03_GLDAS_scatter',6.9)
w.page('GLDAS matched temporal histories');w.fig('A10_gldas_temporal_all_basins',6.9)
w.page('Residual and modeled human trend maps');w.fig('A06_residual_spatial',5.1);w.text('Residual and independent observations',[0])
w.page('TWSA residual histories');w.fig('A07_residual_TWSA_temporal',6.9)
w.page('GWSA residual histories');w.fig('A08_residual_GWSA_temporal',6.9)
w.page('GLDAS and residual temporal comparison');w.fig('A12_gldas_residual_temporal',6.9)
w.page('ENSO associations in space');w.fig('P07_ENSO_spatial_TWSA',2.8);w.fig('P08_ENSO_spatial_GWSA',2.8)
w.page('ENSO lead and index sensitivity');w.fig('P09_ENSO_lag_sensitivity',4.5);w.text('ENSO results',[0,1])
w.page('ENSO phase conditions and climate skill');w.fig('P10_ENSO_composites',3.4);w.fig('P11_ENSO_model_skill',2.2);w.text('ENSO results',[2])
w.page('Groundwater agreement in space');w.fig('A15_residual_validation_spatial',5.5);w.text('Residual and independent observations',[1])
w.page('Groundwater and residual temporal histories');w.fig('A16_residual_validation_temporal',6.9)
w.page('Independent reservoir evidence');w.fig('A17_reservoir_validation_spatial',3.0);w.fig('reservoir_national',2.4);w.text('Residual and independent observations',[2])
w.page('Groundwater agreement values by basin');w.basin_table(7);w.para('An unavailable correlation is an observation gap, not zero effect. The full release also includes matched GLDAS scores, reservoir counts and intervals, additive component slopes, forcing summaries and ENSO diagnostics for each basin. Groundwater head is a supporting state measurement; no cross-unit volume error score is calculated.')
w.page('Discussion',5);w.text('Discussion')
w.page('Conclusions and reproducible workflow',6);w.text('Conclusions');w.para('Repository  https://github.com/pratikkhanal16/thailand-water-storage-dss\nWebsite  https://pratikkhanal16.github.io/thailand-water-storage-dss/\nStart with research_v6/README.md for commands and the distinction between frozen-input verification and the complete raw-input rebuild.',size=10.5,spacing=1.15)
w.page('References')
for s in refs:w.para(s,size=9.5,spacing=1,after=5,align=A.LEFT)
assert len(w.pages)==50,len(w.pages)
report=w.save(V/'report/AIT_Report_Farzeen_Khan.docx')

# Separate journal manuscript: argument and results first, selected figures at end.
m=Writer('Attribution credibility of water storage change across Thailand')
m.para('Attribution credibility of water storage change across Thailand',size=16,bold=True,align=A.CENTER,spacing=1.2,style='Title');m.para('Farzeen Khan\nWater Engineering and Management, Asian Institute of Technology\nAdvisor: Dr. Natthachet Tangdamrongsub',align=A.CENTER,spacing=1.1)
m.heading('Abstract');m.para(ABSTRACT);m.para('Keywords  GRACE groundwater storage climate memory ENSO uncertainty',size=11,spacing=1)
for num,title,keys in [('1','Introduction',['Introduction','Literature and research gap','Contribution and hypotheses']),('2','Study area and data',['Study area and reporting scale','Data and provenance']),('3','Methods',['Common units reference and missing data','Groundwater storage balance','Trends and significance','Climate reconstruction design','Residual and represented human effect','Evaluation and independent evidence','ENSO and IOD diagnostics']),('4','Results',['Storage results','Climate and GLDAS results','Residual and independent observations','ENSO results']),('5','Discussion',['Discussion']),('6','Conclusions',['Conclusions'])]:
 m.heading(num+' '+title,1)
 for i,key in enumerate(keys):
  if len(keys)>1:m.heading(num+'.'+str(i+1)+' '+key)
  m.text(key)
m.heading('Data and code availability',1);m.para('All analysis inputs, provenance, frozen climate indices, reference outputs and executable workflows are supplied in the public repository https://github.com/pratikkhanal16/thailand-water-storage-dss. Original source datasets remain subject to their provider terms. The dashboard and release downloads are available at https://pratikkhanal16.github.io/thailand-water-storage-dss/. No synthetic groundwater observations or assumed specific-yield conversions are introduced.')
m.heading('Study scope and declarations',1);m.para('This manuscript is prepared for advisor review. The analysis does not establish a validated human-only water balance. Author contributions, funding, conflicts of interest and final author order must be confirmed by the author and advisor before journal submission; no committee approval, funding award or signature is implied.')
m.heading('References',1)
for s in refs:m.para(s,size=10.5,spacing=1.1,after=7,align=A.LEFT)
for stem in ['A01_observed_spatial','05_product_ranking_scatter','13_climate_memory_ablation','A13_climate_evaluation_spatial','P06_period_benchmarks','A06_residual_spatial','P07_ENSO_spatial_TWSA','P09_ENSO_lag_sensitivity','A15_residual_validation_spatial','reservoir_national']:
 m.page(C[stem]['title']);m.fig(stem,5.8)
m.page('Selected basin performance tables');m.basin_table(2);m.page('Groundwater climate reconstruction performance');m.basin_table(3)
manuscript=m.save(V/'manuscript/Manuscript_Farzeen_Khan.docx')
(V/'qa/document_plan.json').write_text(json.dumps({'report':report,'manuscript':manuscript,'fonts':'Times New Roman body 12 pt; chapter headings 14 pt','report_body_line_spacing':1.5,'report_intended_pages':50},indent=2),encoding='utf-8')
(V/'manuscript/Manuscript_Farzeen_Khan.md').write_text('# Attribution credibility of water storage change across Thailand\n\nFarzeen Khan\n\n## Abstract\n\n'+ABSTRACT+'\n\n'+'\n\n'.join('## '+key+'\n\n'+'\n\n'.join(value) for key,value in SECTIONS.items())+'\n\n## References\n\n'+'\n\n'.join(refs),encoding='utf-8')
print('Authored report:',len(w.pages),'planned pages,',w.nfig,'figures;',w.ntab,'tables. Manuscript:',m.nfig,'figures.')
