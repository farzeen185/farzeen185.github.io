# Academic presentation

Author: Farzeen Khan. Advisor: Dr. Natthachet Tangdamrongsub.
26 main slides + 8 supporting slides. Theme: Metropolis (Matthias Vogelgesang and contributors), https://github.com/matze/mtheme.

Compile the standalone source twice with XeLaTeX:

```
xelatex Thailand_Water_Storage_Seminar.tex
xelatex Thailand_Water_Storage_Seminar.tex
```

Install Beamer, Metropolis, fontspec, graphics and booktabs through your TeX distribution. Arial is used if installed; otherwise TeX Gyre Heros is selected. Keep the supplied `figures/` directory beside the `.tex` file. The PDF retains vector charts. The PowerPoint uses editable text and native performance tables with scientific plot images. Both versions carry the same scientific narrative.
