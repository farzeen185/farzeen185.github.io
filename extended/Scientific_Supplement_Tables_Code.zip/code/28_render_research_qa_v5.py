"""Render every final PDF page and produce labelled contact sheets."""
from pathlib import Path
from pdf2image import convert_from_path
from pypdf import PdfReader
from PIL import Image,ImageOps,ImageDraw
import json,hashlib
ROOT=Path(__file__).resolve().parents[1];O=ROOT/'Thailand_Research_v5';Q=O/'logs/qa';Q.mkdir(exist_ok=True)
pop=Path('C:/Users/ASUS/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/Library/bin')
records=[]
for label,path in [('report',O/'report/AIT_Extended_Thesis_Farzeen_Khan.pdf'),('manuscript',O/'manuscript/Manuscript_Attribution_Credibility_Farzeen_Khan.pdf'),('beamer',O/'presentation/Thailand_Attribution_Credibility_Beamer.pdf')]:
    out=Q/'final'/label;out.mkdir(exist_ok=True,parents=True);reader=PdfReader(path)
    texts=[p.extract_text() for p in reader.pages]
    assert not any('Error! Reference' in t or 'MITOCHONDRIAL' in t for t in texts)
    assert 'Farzeen Khan' in texts[0]
    if label=='report':assert len(texts)==60
    prefix=label+'_'+hashlib.sha256(path.read_bytes()).hexdigest()[:10]
    pages=convert_from_path(str(path),dpi=95,output_folder=str(out),fmt='png',output_file=prefix,paths_only=True,poppler_path=str(pop),thread_count=3)
    assert len(pages)==len(reader.pages),(label,len(pages),len(reader.pages))
    for batch in range(0,len(pages),12):
        thumbsize=(280,400) if label!='beamer' else (400,250)
        sheet=Image.new('RGB',(thumbsize[0]*4,thumbsize[1]*3),'#dce2e7');draw=ImageDraw.Draw(sheet)
        for k,p in enumerate(pages[batch:batch+12]):
            im=Image.open(p);im.thumbnail((thumbsize[0]-12,thumbsize[1]-26));x=(k%4)*thumbsize[0];y=(k//4)*thumbsize[1];sheet.paste(im,(x+6,y+20));draw.text((x+8,y+4),f'{label} page {batch+k+1}',fill='black')
        sheet.save(Q/f'{label}_contact_{batch//12+1:02d}.png')
    records.append({'artifact':label,'pages':len(texts),'words':sum(len(t.split()) for t in texts),'min_page_words':min(len(t.split()) for t in texts),'rendered_pages':len(pages)})
(Q/'pagination.json').write_text(json.dumps(records,indent=2));print(records)
