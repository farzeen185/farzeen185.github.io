"""Portable extension: reuse the tested original package, then recompute v5."""
from pathlib import Path
import shutil,json,hashlib
R=Path(__file__).resolve().parents[1];P=R/'Thailand_Objective3/web_app/research_v5';P.mkdir(exist_ok=True)
for folder in ['scripts','reference','inputs']:(P/folder).mkdir(exist_ok=True)
names=['17_csr_storage_attribution_v5.py','18_attribution_robustness_v5.py','19_climate_tests_v5.py','20_groundwater_network_v5.py','21_figures_synthesis_v5.py','29_reservoir_validation_v5.py']
for name in names:shutil.copy2(R/'scripts'/name,P/'scripts'/name)
shutil.copy2(P.parent/'research/scripts/research_common.py',P/'scripts/research_common.py')
files=list((R/'shared_data/CSR_RL0603').glob('*_Thailand.nc'))+[R/'shared_data/surface_water/G3P_v1.12_TWS_Thailand_buffer_monthly_200204_202309.nc',R/'Thailand_Objective2/outputs_advanced/Step_06_Final_Harmonized_Cube/netcdf/Climate_Inputs_2003_2024.nc']
files += [R/'shared_data/reservoir_independent'/x for x in ['MSEA_Thailand_monthly.csv','MSEA_Thailand_inventory.csv','provenance.json','zenodo_record.json']]
manifest=[]
for f in files:
    assert f.is_file(),f
    rel=f.relative_to(R);dst=P/'inputs'/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,dst)
    manifest.append({'path':rel.as_posix(),'bytes':dst.stat().st_size,'sha256':hashlib.sha256(dst.read_bytes()).hexdigest()})
for f in (R/'Thailand_Research_v5/tables').glob('*.csv'):shutil.copy2(f,P/'reference'/f.name)
for f in [R/'reports/RESEARCH_V5_PROTOCOL.md',R/'shared_data/CSR_RL0603/provenance.json',R/'shared_data/CSR_RL0603/CSR_month_assignment_audit.csv']:
    shutil.copy2(f,P/f.name)
(P/'input_manifest.json').write_text(json.dumps({'files':manifest,'total_bytes':sum(x['bytes'] for x in manifest)},indent=2))
shutil.copy2(P.parent/'research/requirements-lock.txt',P/'requirements-lock.txt')
shutil.copy2(P.parent/'research/environment.yml',P/'environment.yml')
print('Packaged',len(manifest),'additional inputs;',sum(x['bytes'] for x in manifest)/1e6,'MB;',len(list((P/'reference').glob('*.csv'))),'reference tables')
