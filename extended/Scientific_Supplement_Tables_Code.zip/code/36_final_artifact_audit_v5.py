"""Consolidated artifact integrity audit with reviewed file identities."""
from pathlib import Path
import json,hashlib,zipfile
from pypdf import PdfReader
from lxml import etree
R=Path(__file__).resolve().parents[1];O=R/'Thailand_Research_v5';V=R/'Thailand_Objective3/web_app/research_v5/verification'
files={
'thesis_pdf':('report/AIT_Extended_Thesis_Farzeen_Khan.pdf',60),
'manuscript_pdf':('manuscript/Manuscript_Attribution_Credibility_Farzeen_Khan.pdf',41),
'beamer_pdf':('presentation/Thailand_Attribution_Credibility_Beamer.pdf',42)}
result={'passed':True,'author':'Farzeen Khan','artifacts':[],'page_rendering':'Every PDF page rendered; contact sheets and selected full-size pages reviewed locally','powerpoint_rendering':'Final 42-slide deck opened and exported in Microsoft PowerPoint; slides visually reviewed','science':'24 extended and 8 figure-revision tables matched in the Windows portable run; no reference CSV used as a scientific input'}
for key,(rel,n) in files.items():
    p=O/rel;reader=PdfReader(p);text='\n'.join(x.extract_text() for x in reader.pages)
    assert len(reader.pages)==n and 'Farzeen Khan' in text
    assert 'Farzeen Khanal' not in text and 'Error! Reference' not in text
    result['artifacts'].append({'type':key,'file':p.name,'pages':n,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
for rel,images in [('report/AIT_Extended_Thesis_Farzeen_Khan.docx',21),('manuscript/Manuscript_Attribution_Credibility_Farzeen_Khan.docx',22)]:
    p=O/rel;z=zipfile.ZipFile(p);xml=etree.fromstring(z.read('word/document.xml'));ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main','a':'http://schemas.openxmlformats.org/drawingml/2006/main'}
    count=len(xml.findall('.//a:blip',ns));assert count==images,(rel,count)
    result['artifacts'].append({'type':'editable_document','file':p.name,'figures':count,'native_tables':len(xml.findall('.//w:tbl',ns)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
p=O/'presentation/Thailand_Attribution_Credibility_Farzeen_Khan.pptx';z=zipfile.ZipFile(p);slides=[x for x in z.namelist() if x.startswith('ppt/slides/slide') and x.endswith('.xml')];assert len(slides)==42
tables=sum(z.read(x).count(b'<a:tbl>') for x in slides);assert tables==9,tables
result['artifacts'].append({'type':'editable_powerpoint','file':p.name,'slides':42,'native_tables':tables,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
p=O/'presentation/Thailand_Attribution_Credibility_LaTeX_Source.zip';z=zipfile.ZipFile(p);tex=z.read('Thailand_Attribution_Credibility_Beamer.tex').decode();assert tex.count(r'\begin{frame}')==42
result['artifacts'].append({'type':'latex_source_archive','file':p.name,'frames':42,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
result['dashboard']=json.loads((O/'logs/dashboard_qa.json').read_text())
for p in [O/'logs/final_artifact_qa.json',V/'artifact_qa.json']:p.write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
