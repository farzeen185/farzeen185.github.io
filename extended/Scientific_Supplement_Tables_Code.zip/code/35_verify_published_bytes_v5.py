"""Verify git object input bytes and deployed artifact SHA-256 values."""
from pathlib import Path
import subprocess,json,hashlib,requests
R=Path(__file__).resolve().parents[1];W=R/'Thailand_Objective3/web_app';P=W/'research_v5'
manifest=json.loads((P/'input_manifest.json').read_text());gitchecks=[]
for f in manifest['files']:
    rel='research_v5/inputs/'+f['path'];raw=subprocess.run(['git','show','HEAD:'+rel],cwd=W,capture_output=True,check=True).stdout
    assert hashlib.sha256(raw).hexdigest()==f['sha256'],rel
    gitchecks.append(rel)
result={'git_inputs_verified':len(gitchecks),'git_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip(),'published':[]}
for name in ['AIT_Extended_Thesis_Farzeen_Khan.pdf','Manuscript_Attribution_Credibility_Farzeen_Khan.pdf','Thailand_Attribution_Credibility_Farzeen_Khan.pptx','Thailand_Attribution_Credibility_Beamer.pdf','Thailand_Attribution_Credibility_LaTeX_Source.zip']:
    url='https://pratikkhanal16.github.io/thailand-water-storage-dss/extended/'+name
    q=requests.get(url,timeout=90);q.raise_for_status();want=hashlib.sha256((W/'extended'/name).read_bytes()).hexdigest();got=hashlib.sha256(q.content).hexdigest()
    assert got==want,name+' deployment differs'
    result['published'].append({'file':name,'bytes':len(q.content),'sha256':got})
result['passed']=True;(R/'Thailand_Research_v5/logs/published_bytes_qa.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
