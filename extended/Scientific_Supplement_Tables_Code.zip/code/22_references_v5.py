"""Retain authoritative bibliographic metadata for the extended study."""
import json,concurrent.futures
from pathlib import Path
import requests
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'Thailand_Research_v5/logs'
dois=['10.1002/2016JB013007','10.15781/cgq9-nh24','10.5194/essd-17-611-2025','10.5194/hess-29-6985-2025','10.5194/gmd-17-8817-2024','10.5880/G3P.2024.001','10.1175/BAMS-85-3-381','10.1016/j.jhydrol.2021.126868','10.3390/rs17101731','10.3390/rs14010173','10.1038/sdata.2015.66','10.5194/gmd-10-1903-2017','10.5194/essd-11-717-2019','10.1029/WR018i001p00107','10.1029/WR020i006p00727','10.1080/01621459.1968.10480934','10.1111/j.2517-6161.1995.tb02031.x','10.1111/ecog.02881','10.1023/A:1010933404324','10.1111/j.1467-9868.2005.00503.x','10.1080/00401706.1970.10488634','10.1016/j.jhydrol.2009.08.003','10.5194/hess-23-4323-2019','10.1162/rest.90.3.414','10.1016/j.jeconom.2008.08.003','10.1029/2009WR008564','10.5194/hess-26-1579-2022','10.5194/hess-23-5089-2019']
def get(doi):
    r=requests.get('https://api.crossref.org/works/'+doi,timeout=40)
    if r.status_code==200:
        m=r.json()['message'];return doi,{k:m.get(k) for k in ['DOI','title','author','published','container-title','volume','issue','page','article-number','URL','publisher']}
    return doi,{'DOI':doi,'status':r.status_code,'url':'https://doi.org/'+doi}
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:data=dict(pool.map(get,dois))
data['GROW']=json.loads((ROOT/'reports/grow_reference_metadata.json').read_text(encoding='utf-8'))
data['WaterGAP_datasets']=json.loads((ROOT/'shared_data/WaterGAP/publisher_inventory.json').read_text(encoding='utf-8'))
(OUT/'bibliographic_metadata.json').write_text(json.dumps(data,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps({k:v.get('title',v.get('status')) for k,v in data.items() if k not in ['GROW','WaterGAP_datasets']},indent=2,ensure_ascii=True))
