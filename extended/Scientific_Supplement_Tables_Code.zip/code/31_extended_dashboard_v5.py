"""Export extended results and reviewed artifacts without replacing the original study."""
from pathlib import Path
import json,shutil
import pandas as pd,numpy as np
R=Path(__file__).resolve().parents[1];O=R/'Thailand_Research_v5';W=R/'Thailand_Objective3/web_app/extended';W.mkdir(exist_ok=True)
names=['CSR_basin_trends.csv','native_mascon_support.csv','CSR_groundwater_network_evidence.csv','climate_feature_ablation.csv','independent_reservoir_evidence.csv','common_support_product_audit.csv','attribution_wild_block_intervals.csv']
records=lambda f:json.loads(f.to_json(orient='records',date_format='iso'))
d={n[:-4]:records(pd.read_csv(O/'tables'/n,dtype={'region':str})) for n in names}
f=pd.read_csv(O/'tables/CSR_naturalized_attribution.csv',dtype={'region':str});z=pd.read_csv(O/'tables/independent_reservoir_timeseries.csv',dtype={'region':str});d['series']={}
for code,g in f.groupby('region'):
    d['series'][code]={var:records(v[['date','observed_mm','climate_mm','residual_mm','modeled_human_mm','discrepancy_mm']]) for var,v in g.groupby('variable')}
    d['series'][code]['reservoir']=records(z[(z.region==code)&(z.level==2)][['date','SWSA_reservoir_mm']])
d['meta']={'author':'Farzeen Khan','date':'2026-10-25','gravity':'CSR RL06.3','reference':'2004–2009','interpretation':'R = O − C = H + E. Residual is not directly observed human depletion. All 22 basin estimates retain provider small-support caution.'}
(W/'analysis.json').write_text(json.dumps(d,separators=(',',':'),ensure_ascii=False),encoding='utf-8')
for name in names:shutil.copy2(O/'tables'/name,W/name)
files=['report/AIT_Extended_Thesis_Farzeen_Khan.docx','report/AIT_Extended_Thesis_Farzeen_Khan.pdf','manuscript/Manuscript_Attribution_Credibility_Farzeen_Khan.docx','manuscript/Manuscript_Attribution_Credibility_Farzeen_Khan.pdf','presentation/Thailand_Attribution_Credibility_Farzeen_Khan.pptx','presentation/Thailand_Attribution_Credibility_Beamer.pdf','presentation/Thailand_Attribution_Credibility_LaTeX_Source.zip']
for name in files:shutil.copy2(O/name,W/Path(name).name)
print('Exported extended dashboard and',len(files),'artifacts')
