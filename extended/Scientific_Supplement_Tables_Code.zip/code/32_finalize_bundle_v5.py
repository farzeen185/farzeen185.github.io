"""Build self-contained LaTeX archive and scientific supplement."""
from pathlib import Path
import zipfile,json,hashlib,shutil
R=Path(__file__).resolve().parents[1];O=R/'Thailand_Research_v5';P=O/'presentation'
with zipfile.ZipFile(P/'Thailand_Attribution_Credibility_LaTeX_Source.zip','w',zipfile.ZIP_DEFLATED) as z:
    for f in [P/'Thailand_Attribution_Credibility_Beamer.tex',P/'README.md',P/'slide_content.json']+list((P/'figures').glob('*.pdf')):z.write(f,f.relative_to(P))
with zipfile.ZipFile(O/'Scientific_Supplement_Tables_Code.zip','w',zipfile.ZIP_DEFLATED) as z:
    for f in list((O/'tables').glob('*.csv'))+[R/'reports/RESEARCH_V5_PROTOCOL.md']+list((R/'scripts').glob('*v5.py')):
        z.write(f,('tables/'+f.name) if f.parent.name=='tables' else ('code/'+f.name))
PUBLISH=R/'Thailand_Objective3/web_app/research_v5';D=PUBLISH/'document_source';D.mkdir(exist_ok=True)
for name in ['23_write_extended_study.py','24_manuscript_v5.py','25_slides_latex_v5.py','v5_thesis_text.py','render_v5_with_word.ps1']:
    shutil.copy2(R/'scripts'/name,D/name)
for f in [R/'reports/AIT_official_template.docx',O/'logs/bibliographic_metadata.json']:
    target=D/f.name;shutil.copy2(f,target)
shutil.copy2(R/'Thailand_Objective3/web_app/research/scripts/research_common.py',D/'research_common.py')
builder=Path('C:/Users/ASUS/AppData/Local/Temp/codex-presentations/twsa-research/tmp/build_v5.mjs')
shutil.copy2(builder,D/'build_powerpoint_artifact_tool.mjs')
shutil.copy2(O/'Scientific_Supplement_Tables_Code.zip',R/'Thailand_Objective3/web_app/extended/Scientific_Supplement_Tables_Code.zip')
print('LaTeX source archive and scientific supplement created.')
